import numpy as np
from gurobipy import *
from collections import defaultdict
example=1
cuts_type="cb"

if example==1:
    num_k=2
    num_t=2
    num_i=2
    num_j=2
    p=[100,200]
    q_=[10,30]
    c=[0,1]
    a=np.array([[
        [1,0],
        [0,0]],                       
        [[0,0],
        [0,1]
        ]])
    b=np.array([[
        [1,0],
        [0,0]],                      
        [[0,0],
        [0,1]
        ]])
    bar_x=np.array([
        [1,0],
        [1,0]
   ] )
params = dict()
params["num_k"] = num_k
params["num_t"] = num_t
params["num_i"] = num_i
params["p"] = p
params["q_"] = q_
params["c"] = c
params["a"] = a
params["b"] = b

def mp(Q,E,iter_i,parameter,cuts_type):
    num_k  =params["num_k"] 
    num_t  =params["num_t"] 
    num_i  =params["num_i"] 
    p=params["p"] 
    q_=params["q_"] 
    c=params["c"] 
    a=params["a"] 
    b=params["b"]
    stop=False
    print("=" * 20 + " master problem " + "=" * 20)
    master = Model("master")
    x = master.addVars(
        [j for j in range(num_j)],
        [t for t in range(num_t)],
        vtype=GRB.BINARY, name="x"
    )

    q = master.addVar(vtype=GRB.CONTINUOUS, name="q")

    master.addConstrs((
        quicksum(x[j,t] for j in range(num_j)) >= 1
        for t in range(num_t)
    ))
    if cuts_type == "cb":
        # addConstraints do not support dict enumeration
        # combinatorial benders cut
        for item in Q.values():
            master.addConstr(
                quicksum(x[j,t] for (j, t) in item[0]) +
                quicksum(1 - x[j,t] for (j, t) in item[1]) >= 1
            )
    else:
        print("no available cuts types")

    for item in E.values():
        master.addConstr(
            quicksum(-1*item["a"][k]*(p[t]*a[c[t],j,k]*x[j,t]*+q_[t]*b[c[t],j,k]*x[j,t]) for j in range(num_j) for t in range(num_t) for k in range(num_k))+
            quicksum(item["b"][k]*(p[t]*a[c[t],j,k]*x[j,t]+q_[t]*b[c[t],j,k]*x[j,t]) for j in range(num_j) for t in range(num_t) for k in range(num_k))<=q

        )
    print(item["a"])
    print(item["b"])
    master.setObjective(q, GRB.MINIMIZE)
    master.optimize()
    bar_x = dict()
    if master.status == GRB.OPTIMAL:
        for j in range(num_j):
            for t in range(num_t):
                bar_x[ j,t] = 1 if x[ j,t].x > 0.01 else 0
    else:
        print("There is no feasible solution in primal problem")
        stop = True

    return master, bar_x, stop

def sp(Q,E,bar_x,iter_i,parameter):
    num_k  =params["num_k"] 
    num_t  =params["num_t"] 
    num_i  =params["num_i"] 
    p=params["p"] 
    q_=params["q_"] 
    c=params["c"] 
    a=params["a"] 
    b=params["b"]
    stop=False
    print("=" * 20 + " slave problem with cb " + "=" * 20)
    slave = Model("slave")
    u = slave.addVar(0.0,vtype=GRB.CONTINUOUS, name="u")
    l = slave.addVar(0.0,vtype=GRB.CONTINUOUS, name="l")

    con_a = slave.addConstrs((
        -l>=-quicksum(
            p[t]*a[c[t],j,k]*bar_x[j,t]+q_[t]*b[c[t],j,k]*bar_x[j,t] for j in range(num_j) for t in range(num_t)
        ) 
        for k in range(num_k)
    ))
    con_b = slave.addConstrs((
        u>=quicksum(
            p[t]*a[c[t],j,k]*bar_x[j,t]+q_[t]*b[c[t],j,k]*bar_x[j,t] for j in range(num_j) for t in range(num_t)
        ) 
        for k in range(num_k)
    ))
    slave.setObjective(u+l, GRB.MINIMIZE)
    slave.optimize()
    if slave.status == GRB.INFEASIBLE:
        item = dict()
        item[0] = [
            k for k, v in bar_x.items() if v < 0.001
        ]
        item[1] = [
            k for k, v in bar_x.items() if v >= 0.001
        ]
        Q[iter_i] = item
        print("Add feasible cut")
    elif slave.status == GRB.OPTIMAL:
        item = defaultdict()#dict()
        item["a"] = {k: v.pi for k, v in con_a.items()}
        item["b"] = {k: v.pi for k, v in con_b.items()}
        E[iter_i] = item
        print("Add optimal cut")
    else:
        print("wrong slave sub-problem status  " + str(slave.status))
        stop = True

    return slave, stop
# main iteration
E_set = dict()
Q_set = dict()

LB = -1 * 1e10
UB = 1e10

warm_start = True
feasible_cnt = 0
optimal_cnt = 0

for iter_i in range(1000):

    if np.abs(UB - LB) < 0.01:
        print("Optimal")
        break

    print("=" * 100)
    print("iteration at " + str(iter_i))

    if cuts_type == "cb":
        slave, stop = sp(Q_set, E_set, bar_x, iter_i, params)
        

    else:
        print("no available cuts type")
        break

    print("Q  " + str(len(Q_set.keys())))
    print("E  " + str(len(E_set.keys())))

    if stop:
        print("Wong slave problem")
        break
    item = E_set.get(iter_i, False)

    if item:
        print("slave objective value")
        print(slave.objVal)

        dual_optimal = sum(
            [-1*item["a"][k]*p[t]*a[c[t],j,k]*bar_x[j,t]-1*item["a"][k]*q_[t]*b[c[t],j,k]*bar_x[j,t] for j in range(num_j) for t in range(num_t) for k in range(num_k)])+sum([item["b"][k]*(p[t]*a[c[t],j,k]*bar_x[j,t]+q_[t]*b[c[t],j,k]*bar_x[j,t]) for j in range(num_j) for t in range(num_t) for k in range(num_k)])
        

        print("slave dual objective value")
        print(dual_optimal)
        UB=min(UB,dual_optimal)
    master, bar_x, stop = mp(Q_set, E_set, iter_i, params, cuts_type)
    print("bar_x")
    print(bar_x)

    print("master objective value")
    print(master.objVal)

    if stop:
        print("wrong master problem")
        break

    LB = master.objVal

    print("UB " + str(UB))
    print("LB " + str(LB))
