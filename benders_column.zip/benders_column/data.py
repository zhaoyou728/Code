import random
import math
I=10
J=10
K=10
N=1
S=30
warning=[]
def information():
    f.write("{} {} {} {} {}\n".format(I,J,K,N,S))
def point_time():
    x_base=[]
    y_base=[]
    x_site=[]
    y_site=[]
    for i in range(I):
        x_base.append(random.randint(0,40))
        y_base.append(random.randint(0,40))
    for s in range(S):
        for i in range(I):
            for j in range(J):
                x_site.append(random.randint(0,40))
                y_site.append(random.randint(0,40))
                d=math.sqrt((x_site[j]-x_base[i])*(x_site[j]-x_base[i])+(y_site[j]-y_base[i])*(y_site[j]-y_base[i]))
                t=d/20*60
                f.write("{} ".format(t))
            x_site=[]
            y_site=[]
            f.write("\n")
            
def warning_time():
    for s in range(S):
        for j in range(J):
            warning=random.randint(0,1440)
            f.write("{} ".format(warning))
        f.write("\n")
def service_time():
    for s in range(S):
        for j in range(J):
            service=random.randint(0,100)
            f.write("{} ".format(service))
        f.write("\n")
def demand_vehicle():
    for s in range(S):
        for j in range(J):
            demand=1
            f.write("{} ".format(demand))
        f.write("\n")
def setup_time():
    for s in range(S):
        for j in range(J):
            setup=random.randint(1,5)
            f.write("{} ".format(setup))
        f.write("\n")
def big_m():
    for s in range(S):
        for j in range(J):
            big_m=200
            f.write("{} ".format(big_m))
        f.write("\n")
    
    
f=open("data_1.txt","w")
information()
point_time()
warning_time()
service_time()
demand_vehicle()
big_m()
setup_time()

    
