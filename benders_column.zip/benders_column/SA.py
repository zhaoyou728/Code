import numpy as np
from matplotlib import pyplot as plt
from gurobipy import *
from collections import defaultdict
import datetime
import random
cuts_type="general+cb"
def read_data(filename):
    f=open(filename,"r")
    line=f.readline()
    items = line.split()
    num_fire_department=int(items[0])
    num_site=int(items[1])
    num_vehicle=int(items[2])
    num_layer=int(items[3])
    num_s=int(items[4])
    #read i,j,n,k
    I=range(num_fire_department)
    J=range(num_site)
    K=range(num_vehicle)
    N=range(num_layer)
    S=range(num_s)
#read t[i,j]
    t_distance={}
    for s in S:
        for i in I:
            line=f.readline()
            items = line.split()
            for j in J:
                t_distance[s,i,j]=float(items[j])
#read u[j]

    u_call={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            u_call[s,j]=(int(items[j]))
#read s[j]

    s_service={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            s_service[s,j]=(int(items[j]))       
#read d[j]
    d_demand={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
             d_demand[s,j]=(int(items[j]))

#read M[j]


    big_M={}
    for s in S:
        line=f.readline()
        items = line.split()        
        for j in J:
            big_M[s,j]=(int(items[j]))
#read e[k]
    e_setup={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            e_setup[s,j]=(int(items[j]))


    return num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup

def daigas_low(bar_y,parameter):
    num_s=params["num_s"] 
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"]
    big_M=params["big_M"] 
    e_setup = params["e_setup"]
    stop = False
   ####################################################
    print("="*100+ "daigas sub problem " +"="*100)
    daigas=Model("daigas")
    c=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )

    x=daigas.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="x"
    )
    # y=daigas.addVars(
    #     [i for i in range(num_fire_department)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY, name="y"
    # )
    # daigas.addConstrs((
    #     quicksum(
    #         y[i,k] for i in range(num_fire_department)
    #     )==1
    #     for k in range(num_vehicle)

    #     ))
    temp=daigas.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )
    daigas.addConstrs((
        bar_y[i,k]+x[s,j,n,k]-1<=temp[s,i,j,n,k]
            for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))

    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))


    # daigas.addConstrs((
    #     t_[s,n,k]>=t_distance[s,i,j]-(1-x[s,j,n,k])*big_M[s,j]-(1-bar_y[i,k])*big_M[s,j]
    #     for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    # ))
    daigas.addConstrs((
        t_[s,n,k]>=quicksum(temp[s,i,j,n,k]*t_distance[s,i,j] for i in range(num_fire_department) for j in range(num_site))
         for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        c[s,n,k]>=quicksum(x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    
    daigas.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]

        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
                    

    daigas.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(
                        x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    daigas.optimize()
    return daigas.objVal

def initial(I,K):
    array={}
    for i in range(I):
        for k in range(K):
            array[i,k]=0
    for k in range(K):
        array[random.randint(1,10)% num_fire_department,k]=1
        #random.randint(1,10)% num_fire_department
    # for i in range(I):
    #      if sum(array[i,k] for k in range(num_vehicle))>=2:
    #          initial(I,K) 
            
    return array
######################
#   get the index       
######################
def get_index(left,right,number,array):
    for k in range(left,right):
        for i in range(number):
            if array[i,k]==1:
                return i

def swap_search(start,end,st_left,st_right,allocation):
    #num_fire_department+start-1  
    for k in range(st_left,st_right):
        for i in range(start,end):
            if allocation[(i)%num_fire_department,k]==1:
                allocation[(i)%num_fire_department,k],allocation[(i-1)%num_fire_department,k]=allocation[(i-1)%num_fire_department,k],allocation[(i)%num_fire_department,k]
#random.randint(1,num_vehicle-1)
    return allocation


argvs=sys.argv
argc=len(argvs)
if (argc<=1):
    print("usage: #python %s filename" % argvs[0])
    quit()
num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup=read_data(argvs[1])
params = dict()
params["num_fire_department"] = num_fire_department
params["num_site"] = num_site
params["num_vehicle"] = num_vehicle
params["num_layer"] = num_layer
params["num_s"] = num_s
params["t_distance"] = t_distance
params["u_call"] = u_call
params["s_service"] = s_service
params["d_demand"] = d_demand
params["big_M"] = big_M
params["e_setup"] = e_setup
               
######################
#    Initial              
######################

T=100
t=70
alpha=0.95
markov_len=3
allocation={}
current_allocation=[]
for i in range(num_vehicle):
    current_allocation.append(random.randint(1,100)%num_fire_department)
print(current_allocation)
new_allocation=current_allocation.copy()
best_allocation=current_allocation.copy()
for a in range(num_fire_department):
    for  b in range(num_vehicle):
        allocation[a,b]=0
for j in range(num_vehicle):
    allocation[best_allocation[j],j]=1
print(allocation)
starttime = datetime.datetime.now()
current_solution=daigas_low(allocation,params)
best_solution=current_solution
new_solution=current_solution
order=[]

sequence=[]
while T>t:
    for iter in range(markov_len):
        #while True:
        

        while True:#index of vehicle randomly
            k_1=np.random.randint(0,num_vehicle,2)
            if k_1[0]!=k_1[1]:
                break
        print(k_1)
        while True:#index of fire department randomly
            k_2=np.random.randint(0,num_fire_department,2)
            if k_2[0]!= current_allocation[k_1[0]] and k_2[1]!= current_allocation[k_1[1]]:
                break
        print(k_2)
        print(allocation)
        new_allocation[k_1[0]]=k_2[0]
        new_allocation[k_1[1]]=k_2[1]
        # new_allocation=[]
        # for i in range(num_vehicle):
        #     new_allocation.append(random.randint(1,100)%num_fire_department)
        for a in range(num_fire_department):
            for  b in range(num_vehicle):
                allocation[a,b]=0
        for j in range(num_vehicle):
            allocation[new_allocation[j],j]=1        
        print("########################")
        new_solution=daigas_low(allocation,params)
        order.append(new_solution)
        if new_solution < current_solution:
            current_solution=new_solution
            current_allocation=new_allocation.copy()
            if new_solution<best_solution:
                best_solution=new_solution
                best_allocation=new_allocation.copy()
                #sequence.append(best_allocation)
            else:
                delta=new_solution-current_solution
                if np.random.rand()<np.exp(-delta/T):
                    current_solution=new_solution
                    current_allocation=new_allocation.copy()
                else:
                    new_allocation=current_allocation.copy()
        #order.append(current_solution)
        sequence.append(best_solution)
        
    T=T*alpha
    print(T)
    print(current_allocation,current_solution)
endtime = datetime.datetime.now()
print(endtime - starttime)
print(allocation,best_solution)
print(order)
plt.figure(1)
plt.subplot(211)
#for i in range(len(order)):
plt.plot(order)
plt.subplot(212)
plt.plot(sequence)
plt.show()
