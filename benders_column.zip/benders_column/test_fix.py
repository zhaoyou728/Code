#This program is used to solve the LP relaxation and roudning
#Date:2019/05/30
#author: You Zhao
import numpy as np
from gurobipy import *
from collections import defaultdict
import datetime
import random
from matplotlib import pyplot as plt
cuts_type="general+cb"
N_0={}
N_1={}
N_y_0={}
N_y_1={}
Sum_x={}
Sum_y={}
Obj=0
def read_data(filename):
    f=open(filename,"r")
    line=f.readline()
    items = line.split()
    num_fire_department=int(items[0])
    num_site=int(items[1])
    num_vehicle=int(items[2])
    num_layer=int(items[3])
    num_s=int(items[4])
    #read i,j,n,k
    I=range(num_fire_department)
    J=range(num_site)
    K=range(num_vehicle)
    N=range(num_layer)
    S=range(num_s)
#read t[i,j]
    t_distance={}
    for s in S:
        for i in I:
            line=f.readline()
            items = line.split()
            for j in J:
                t_distance[s,i,j]=float(items[j])
#read u[j]

    u_call={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            u_call[s,j]=(int(items[j]))
#read s[j]

    s_service={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            s_service[s,j]=(int(items[j]))       
#read d[j]
    d_demand={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
             d_demand[s,j]=(int(items[j]))

#read M[j]


    big_M={}
    for s in S:
        line=f.readline()
        items = line.split()        
        for j in J:
            big_M[s,j]=(int(items[j]))
#read e[k]
    e_setup={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            e_setup[s,j]=(int(items[j]))


    return num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup
def daigas_low(parameter):
    num_s=params["num_s"] 
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"]
    big_M=params["big_M"] 
    e_setup = params["e_setup"]
    stop = False
   ####################################################
    print("="*100+ "daigas sub problem " +"="*100)
    daigas=Model("daigas")
    c=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )

    x=daigas.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        ub=1,lb=0,vtype=GRB.CONTINUOUS, name="x"
    )
    y=daigas.addVars(
        [i for i in range(num_fire_department)],
        [k for k in range(num_vehicle)],
        ub=1,lb=0,vtype=GRB.CONTINUOUS, name="y"
    )
    temp=daigas.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        ub=1,lb=0,vtype=GRB.CONTINUOUS,name="temp"

    )
    # x=daigas.addVars(
    #     [s for s in range(num_s)],
    #     [j for j in range(num_site)],
    #     [n for n in range(num_layer)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY,name="x"
    # )

    # y=daigas.addVars(
    #     [i for i in range(num_fire_department)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY, name="y"
    # )
    # temp=daigas.addVars(
    #     [s for s in range(num_s)],
    #     [i for i in range(num_fire_department)],
    #     [j for j in range(num_site)],
    #     [n for n in range(num_layer)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY,name="temp"

    # )



    daigas.addConstrs((
        y[i,k]+x[s,j,n,k]>=2*temp[s,i,j,n,k]
            for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))

    daigas.addConstrs((
        quicksum(
            y[i,k] for i in range(num_fire_department)
        )==1
        for k in range(num_vehicle)

        ))

    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))
    daigas.addConstrs((
        t_[s,n,k]>=quicksum(temp[s,i,j,n,k]*t_distance[s,i,j] for i in range(num_fire_department) for j in range(num_site))
         for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))

    # daigas.addConstrs((
    #     t_[s,n,k]>=t_distance[s,i,j]-(1-x[s,j,n,k])*big_M[s,j]-(1-y[i,k])*big_M[s,j]
    #     for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    # ))

    daigas.addConstrs((
        c[s,n,k]>=quicksum(x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    
    daigas.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]

        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
                    

    daigas.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(
                        x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)

    for iter in range(3):
        
        daigas.setParam("TimeLimit",100)
        daigas.optimize()
        
        
        if daigas.status == GRB.OPTIMAL:

            for i in range(num_fire_department):
                for k in range(num_vehicle):
                    if y[i,k].X==1.0:
                        N_y_1[i,k]=1
                        daigas.addConstr((
                            y[i,k]==1
                        ))
                        print(y[i,k])
                    else:
                        N_y_0[i,k]=0
                        daigas.addConstr((
                            y[i,k]==0
                        ))
            Sum_y.update(N_y_1)
            Sum_y.update(N_y_0) 
            for s in range(num_s):
                for j in range(num_site):
                    for n in range(num_layer):
                        for k in range(num_vehicle):
                            if x[s,j,n,k].X>0.9:        
                                N_1[s,j,n,k]=1
                                daigas.addConstr((
                                    x[s,j,n,k]==1
                                ))
                            else:
                                N_0[s,j,n,k]=0
                                daigas.addConstr((
                                    x[s,j,n,k]==0
                                ))
                                
            print(len(N_1))
            Sum_x.update(N_1)
            Sum_x.update(N_0)
    print(N_1)      
    print(len(N_1))
    print(N_y_1)
    return daigas
def trial(x):
    #for i in range(int(math.floor(c * math.log(n)))):
    if random.random() < x:
        return True
    return False
def daigas1_low(parameter):
    global N_0
    global N_1
    global N_y_0
    global N_y_1
    global Obj
    num_s=params["num_s"] 
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"]
    big_M=params["big_M"] 
    e_setup = params["e_setup"]
    stop = False
   ####################################################
    print("="*100+ "daigas sub problem " +"="*100)
    daigas1=Model("daigas1")
    c=daigas1.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas1.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas1.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas1.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas1.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )


    x=daigas1.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="x"
    )

    y=daigas1.addVars(
        [i for i in range(num_fire_department)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="y"
    )

    temp=daigas1.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )
    # daigas1.addConstrs((
    #     y[i,k]+x[s,j,n,k]-1<=temp[s,i,j,n,k]
    #         for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

    #     ))

    for s in range(num_s):
        for i in range(num_fire_department):
            for j in range(num_site):
                for n in range(num_layer) :
                    for k in range(num_vehicle):
                        daigas1.addConstr(
                            temp[s,i,j,n,k]==min_(y[i,k],x[s,j,n,k]))


    daigas1.addConstrs((
        quicksum(
            y[i,k] for i in range(num_fire_department)
        )==1
        for k in range(num_vehicle)

        ))

    daigas1.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    daigas1.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
        ))
    
    daigas1.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))
    daigas1.addConstrs((
        t_[s,n,k]>=quicksum(temp[s,i,j,n,k]*t_distance[s,i,j] for i in range(num_fire_department) for j in range(num_site))
         for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))

    # daigas1.addConstrs((
    #     t_[s,n,k]>=t_distance[s,i,j]-(1-x[s,j,n,k])*big_M[s,j]-(1-y[i,k])*big_M[s,j]
    #     for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    # ))

    daigas1.addConstrs((
        c[s,n,k]>=quicksum(x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    
    daigas1.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas1.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas1.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas1.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]

        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas1.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    # for i in range(num_fire_department):
    #     for k in range(num_vehicle):
    #         if (i,k) in N_y_1:
    #             daigas1.addConstr((
    #                 y[i,k]==1
    #             ))
    # for s in range(num_s):
    #     for j in range(num_site):
    #         for n in range(num_layer):
    #             for k in range(num_vehicle):
    #                 if (s,j,n,k) in N_1:
    #                     daigas1.addConstr((
    #                         x[s,j,n,k]==1
    #                     ))
                        
                    

    daigas1.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    y_1_c=[]
    Obj_iter=[]
    for i in range(num_fire_department):
        for k in range(num_vehicle):
            if (i,k) in N_y_1:
                y_1_c.append(daigas1.addConstr((
                    y[i,k]==1
                )))
    daigas1.update()
    daigas1.optimize()
    if daigas1.status==GRB.OPTIMAL:
        Obj=daigas1.ObjVal
        Obj_iter.append(Obj)
        if daigas1.ObjVal<=Obj:
            Obj=daigas1.ObjVal
            for b in range(len(y_1_c)):
                daigas1.remove(y_1_c[b])
            N_0={}
            N_1={}
            for s in range(num_s):
                for j in range(num_site):
                    for n in range(num_layer):
                        for k in range(num_vehicle):
                            if x[s,j,n,k].X>0.9:        
                                N_1[s,j,n,k]=1
                            else:
                                N_0[s,j,n,k]=0
    length_y=int((num_fire_department*num_vehicle)*1.0)
    length_x=int((num_layer*num_vehicle*num_site*num_s)*1.0)
    starttime = datetime.datetime.now()
    for iter in range(20):
        # for i in range(num_fire_department):
        #     for k in range(num_vehicle):
        y_1_c=[]
        y_0_c=[]
        x_1_c=[]
        x_0_c=[]
        daigas1.addConstr(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle))<=Obj)
        for i in range(length_y):
            i=random.randint(0,100)%num_fire_department
            k=random.randint(0,100)%num_vehicle
            if (i,k) in N_y_1:
                y_1_c.append(daigas1.addConstr((
                    y[i,k]==1
                )))
            if (i,k) in N_y_0:
                y_0_c.append(daigas1.addConstr((
                    y[i,k]==0
                )))
                    
        # for s in range(num_s):
        #     for j in range(num_site):
        #         for n in range(num_layer):
        #             for k in range(num_vehicle):
        for i in range(length_x):
            s=random.randint(0,100)%num_fire_department
            j=random.randint(0,100)%num_site
            n=random.randint(0,100)%num_layer
            k=random.randint(0,100)%num_vehicle

            if (s,j,n,k) in N_1:
                x_1_c.append(daigas1.addConstr((
                    x[s,j,n,k]==1
                )))
            if (s,j,n,k) in N_0:
                x_1_c.append(daigas1.addConstr((
                    x[s,j,n,k]==0
                )))
        daigas1.update()
        daigas1.optimize()
        if daigas1.status==GRB.OPTIMAL:
            Obj_iter.append(daigas1.ObjVal)
            if daigas1.ObjVal<=Obj:
                Obj=daigas1.ObjVal
            for b in range(len(y_1_c)):
                daigas1.remove(y_1_c[b])
            for b in range(len(y_0_c)):
                daigas1.remove(y_0_c[b])
            for b in range(len(x_1_c)):
                daigas1.remove(x_1_c[b])
            for b in range(len(x_0_c)):
                daigas1.remove(x_0_c[b])
            N_0={}
            N_1={}
            N_y_0={}
            N_y_1={}
            for i in range(num_fire_department):
                for k in range(num_vehicle):
                    if y[i,k].X==1.0:
                        N_y_1[i,k]=1
                    else:
                        N_y_0[i,k]=0
            for s in range(num_s):
                for j in range(num_site):
                    for n in range(num_layer):
                        for k in range(num_vehicle):
                            if x[s,j,n,k].X>0.9:        
                                N_1[s,j,n,k]=1
                            else:
                                N_0[s,j,n,k]=0
    endtime = datetime.datetime.now()
    endtime = datetime.datetime.now()
    print("Operation time is:")
    print(endtime - starttime)    
    print(N_y_1)
    print(Obj)
    plt.figure(1)
    plt.subplot(211)
    plt.plot(Obj_iter)
    plt.show()
    return daigas1

argvs=sys.argv
argc=len(argvs)
if (argc<=1):
    print("usage: #python %s filename" % argvs[0])
    quit()
num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup=read_data(argvs[1])

params = dict()
params["num_fire_department"] = num_fire_department
params["num_site"] = num_site
params["num_vehicle"] = num_vehicle
params["num_layer"] = num_layer
params["num_s"] = num_s
params["t_distance"] = t_distance
params["u_call"] = u_call
params["s_service"] = s_service
params["d_demand"] = d_demand
params["big_M"] = big_M
params["e_setup"] = e_setup
daigas=daigas_low(params)
daigas1=daigas1_low(params)

