import numpy as np
from gurobipy import *
from collections import defaultdict
import datetime
import random
cuts_type="general+cb"
def read_data(filename):
    f=open(filename,"r")
    line=f.readline()
    items = line.split()
    num_fire_department=int(items[0])
    num_site=int(items[1])
    num_vehicle=int(items[2])
    num_layer=int(items[3])
    num_s=int(items[4])
#read i,j,n,k
    I=range(num_fire_department)
    J=range(num_site)
    K=range(num_vehicle)
    N=range(num_layer)
    S=range(num_s)
#read t[i,j]
    t_distance={}
    for s in S:
        for i in I:
            line=f.readline()
            items = line.split()
            for j in J:
                t_distance[s,i,j]=float(items[j])
#read u[j] 
    u_call={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            u_call[s,j]=(int(items[j]))
#read s[j]
    s_service={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            s_service[s,j]=(int(items[j]))
                
#read d[j]
    d_demand={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            d_demand[s,j]=(int(items[j]))
#read M[j]
    big_M={}
    for s in S:
         line=f.readline()
         items = line.split()
         for j in J:
             big_M[s,j]=(int(items[j]))
#read e[j]
    e_setup={}
    for s in S:
        line=f.readline()
        items = line.split()        
        for j in J:
            e_setup[s,j]=(int(items[j]))
    
    bar=[]
    for s in range(num_s):
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    bar.append(random.randint(0,1))
    bar_x=np.array(bar).reshape((num_s,num_site,num_layer,num_vehicle))
    bar_y={}
    for i in I:
        for k in K:
            bar_y[i,k]=0
    for k in K:
        bar_y[random.randint(1,10)%num_fire_department,k]=1
    car=[]
    for s in range(num_s):
        for i in I:
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        car.append(random.randint(0,1))
    bar_temp=np.array(car).reshape((num_s,num_fire_department,num_site,num_layer,num_vehicle))

    return bar_y,bar_x,bar_temp,num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup


def mp(Q,E,C,iter_i,parameter,cuts_type):
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"]
    num_s= params["num_s"]
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    big_M = params["big_M"] 
    e_setup = params["e_setup"] 
    stop = False
    print("======================== master problem ====================")
    master = Model("master")
    # x=master.addVars(
    #     [s for s in range(num_s)],
    #     [j for j in range(num_site)],
    #     [n for n in range(num_layer)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY, name="x"
    # )
    # y=master.addVars(
    #     [i for i in range(num_fire_department)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY,name="y"

    # )
    # temp=master.addVars(
    #     [s for s in range(num_s)],
    #     [i for i in range(num_fire_department)],
    #     [j for j in range(num_site)],
    #     [n for n in range(num_layer)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY,name="temp"

    # )
    x=master.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        ub=1,lb=0,vtype=GRB.CONTINUOUS, name="x"
    )

    y=master.addVars(
        [i for i in range(num_fire_department)],
        [k for k in range(num_vehicle)],
        ub=1,lb=0,vtype=GRB.CONTINUOUS, name="y"
        )
    temp=master.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
    ub=1,lb=0,vtype=GRB.CONTINUOUS,name="temp"

    )
    f = master.addVar(vtype=GRB.CONTINUOUS,name="f")

    master.addConstrs((
        quicksum(
            y[i,k] for i in range(num_fire_department)
        )==1
        for k in range(num_vehicle)

        ))
    
    master.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    master.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
            

        ))
    
    master.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))


    master.addConstrs((
        y[i,k]+x[s,j,n,k]>=2*temp[s,i,j,n,k]
            for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))

    # for item in C.values():           
    #         master.addConstr(
    #             quicksum(y[i, k] for (i, k) in item[0]) +
    #             quicksum(1 - y[i, k] for (i, k) in item[1]) <= 2
    #         )
    #         master.addConstr(
    #             quicksum(x[s,j,n, k] for (s,j,n,k) in item[3]) +
    #             quicksum(1 - x[s,j,n, k] for (s,j,n,k) in item[4]) <=2
    #         )


    for item in E.values():
        master.addConstr(
 quicksum(
           [ item["l"][s,n,k]*temp[s,i,j,n,k]*t_distance[s,i,j] for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+quicksum(
               [item["u"][s,n,k]*x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site) for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)])+quicksum(
        [item["q"][s,n,k]*x[s,j,n,k]*e_setup[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) if n>=1 for k in range(num_vehicle)])+quicksum(
[item["p"][s,n,k]*x[s,j,n,k]*s_service[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])<= f
        )


            

    master.setObjective(f-quicksum(x[s,j,n,k]*u_call[s,j] for j in range(num_site) for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    #master.write("test.lp")
    #master.relax()
    
    bar_x = dict()
    bar_y = dict()
    master.optimize()
    if master.status == GRB.OPTIMAL:
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                if y[i,k].X>=0.5:
                    print(y[i,k])
                
        for s in range(num_s):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        if x[s,j,n,k].X>=0.5:
                            print(x[s,j,n,k])
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                bar_y[i, k] = 1 if y[i,k].X > 0.5  else 0
        for s in range(num_s):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        bar_x[s,j,n,k] = 1 if x[s,j,n,k].X > 0.5 else 0
        for s in range(num_s):
            for i in range(num_fire_department):
                for j in range(num_site):
                    for n in range(num_layer):
                        for k in range(num_vehicle):
                            bar_temp[s,i,j,n,k] = 1 if x[s,j,n,k].X > 0.5 else 0
        item = defaultdict(list)
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                if bar_y[i, k] > 0.01:
                    item[1].append((i, k))
                else:
                    item[0].append((i, k))
        for s in range(num_s):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        if bar_x[s,j,n,k] > 0.01:
                            item[4].append((s,j,n,k))
                        else:
                            item[3].append((s,j,n,k))
        C[iter_i] = item
    return master,bar_x,bar_y,bar_temp,stop



def sp_cb(Q,E,bar_x,bar_y,bar_temp,iter_i,parameter):
    
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"]
    num_s= params["num_s"]
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    big_M = params["big_M"] 
    e_setup = params["e_setup"] 
    stop = False
    print("="*20+ "sub problem with cuts" +"="*20)
    slave=Model("slave")
    c=slave.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=slave.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=slave.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=slave.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=slave.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )

    # con_l=slave.addConstrs((
    #     t_[s,n,k]>=t_distance[s,i,j]-(1-bar_x[s,j,n,k])*big_M[s,j]-(1-bar_y[i,k])*big_M[s,j]
    #     for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    # ))
    con_l=slave.addConstrs((
        t_[s,n,k]>=quicksum(bar_temp[s,i,j,n,k]*t_distance[s,i,j] for i in range(num_fire_department) for j in range(num_site))
         for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_u=slave.addConstrs((
        c[s,n,k]>=quicksum(bar_x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_q=slave.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(bar_x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    con_p=slave.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(bar_x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la1=slave.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la2=slave.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]

        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la3=slave.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))             

    slave.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    slave.optimize()

    if slave.status == GRB.OPTIMAL:
        item = dict()
        item["l"] = {k: v.pi for k, v in con_l.items()}
        item["u"] = {k: v.pi for k, v in con_u.items()}
        item["p"] = {k: v.pi for k, v in con_p.items()}
        item["q"] = {k: v.pi for k, v in con_q.items()}
        E[iter_i] = item
        print("Add Optimal cut")
    elif slave.status == GRB.INFEASIBLE:

        item = defaultdict(list)
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                if bar_y[i, k] > 0:
                    item[1].append((i, k))
                else:
                    item[0].append((i, k))
        for s in range(num_s):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        if bar_x[s,j,n,k] > 0:
                            item[4].append((s,j,n,k))
                        else:
                            item[3].append((s,j,n,k))
        item["l"] = {k: v.pi for k, v in con_l.items()}
        item["u"] = {k: v.pi for k, v in con_u.items()}
        item["p"] = {k: v.pi for k, v in con_p.items()}
        item["q"] = {k: v.pi for k, v in con_q.items()}
        Q[iter_i] = item
        print("Add feasible cut")
        slave.optimize()
    else:
        print("wrong slave sub problem status" + str(slave.status))
        stop = True
    return slave,stop
def daigas(bar_y,parameter): 
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"]
    num_s= params["num_s"]
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    e_setup = params["e_setup"]
    big_M = params["big_M"] 
    stop = False
    print("="*100+ "original problem " +"="*100)
    daigas=Model("daigas")
    c=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )

    x=daigas.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,
        name="x"
    )
    temp=daigas.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )


    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))
    daigas.addConstrs((
        bar_y[i,k]+x[s,j,n,k]-1<=temp[s,i,j,n,k]
            for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))

    daigas.addConstrs((
        t_[s,n,k]>=quicksum(temp[s,i,j,n,k]*t_distance[s,i,j] for i in range(num_fire_department) for j in range(num_site))
         for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))

    # daigas.addConstrs((
    #     t_[n,k]>=t_distance[i,j]-(1-x[j,n,k])*big_M[j]-(1-bar_y[i,k])*big_M[j]
    #     for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    # ))
    daigas.addConstrs((
        c[s,n,k]>=quicksum(x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.update()
    daigas.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(
        x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    daigas.Params.TimeLimit=150
    daigas.optimize()
    return daigas

def daigas_low(parameter):
    num_s=params["num_s"] 
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"]
    big_M=params["big_M"] 
    e_setup = params["e_setup"]
    stop = False
   ####################################################
    print("="*100+ "daigas sub problem " +"="*100)
    daigas2=Model("daigas2")
    c=daigas2.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas2.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas2.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas2.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas2.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )

    x=daigas2.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="x"
    )
    y=daigas2.addVars(
        [i for i in range(num_fire_department)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="y"
    )
    temp=daigas2.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )

    daigas2.addConstrs((
        quicksum(
            y[i,k] for i in range(num_fire_department)
        )==1
        for k in range(num_vehicle)

        ))

    daigas2.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    daigas2.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
        ))
    
    daigas2.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))
    daigas2.addConstrs((
        y[i,k]+x[s,j,n,k]-1<=temp[s,i,j,n,k]
            for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))


    daigas2.addConstrs((
        t_[s,n,k]>=t_distance[s,i,j]-(1-x[s,j,n,k])*big_M[s,j]-(1-y[i,k])*big_M[s,j]
        for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    ))

    daigas2.addConstrs((
        c[s,n,k]>=quicksum(x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    
    daigas2.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas2.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas2.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas2.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]

        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas2.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
                    

    daigas2.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(
                        x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    daigas2.Params.TimeLimit=10
    daigas2.optimize()
    bar_y,bar_x,bar_temp={},{},{}
    for i in range(num_fire_department):
            for k in range(num_vehicle):
                bar_y[i, k] = 1 if y[i,k].X > 0.01 else 0
    for s in range(num_s):
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    bar_x[s,j,n,k] = 1 if x[s,j,n,k].X > 0.01 else 0
    for s in range(num_s):
        for i in range(num_fire_department):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        bar_temp[s,i,j,n,k] = 1 if x[s,j,n,k].X > 0.01 else 0
    
    return daigas2,bar_y,bar_x,bar_temp
#main iteration
Q_set = dict()
E_set = dict()
C_set= dict()
B_set=dict()
A_set=dict()

LB = -1*1e10
UB = 1e10

warm_start = True
feasible_cnt = 0
optimal_cnt= 0
argvs=sys.argv
argc=len(argvs)
if (argc<=1):
    print("usage: #python %s filename" % argvs[0])
    quit()
bar_y,bar_x,bar_temp,num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup=read_data(argvs[1])
params = dict()
params["num_fire_department"] = num_fire_department
params["num_site"] = num_site
params["num_vehicle"] = num_vehicle
params["num_layer"] = num_layer
params["num_s"]=num_s 
params["t_distance"] = t_distance
params["u_call"] = u_call
params["s_service"] = s_service
params["d_demand"] = d_demand
params["big_M"] = big_M
params["e_setup"] = e_setup

#daigas2,bar_y,bar_x,bar_temp=daigas_low(params)
starttime = datetime.datetime.now()
for iter_i in range(5):
    if np.abs(UB-LB) < 0.001:
        print("optimal")
        break
    print("="*100)
    print("iteration at" + str(iter_i))

    if cuts_type == "general+cb":
        slave,stop = sp_cb(Q_set,E_set,bar_x,bar_y,bar_temp,iter_i,params)
    else:
        print("no available cuts type")
        break
    print("Q  " + str(len(Q_set.keys())))
    print("E  " + str(len(E_set.keys())))
    
    if stop:
        print("Wong slave problem")
        break

    item = E_set.get(iter_i, False)

    if item:
        print("slave objective value")
        print(slave.objVal)
        dual_optimal= sum(
           [item["l"][s,n,k]*bar_temp[s,i,j,n,k]*t_distance[s,i,j] for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+sum(
               [item["u"][s,n,k]*bar_x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+sum(
        [item["q"][s,n,k]*bar_x[s,j,n,k]*e_setup[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) if n>=1 for k in range(num_vehicle)])+sum(
[item["p"][s,n,k]*bar_x[s,j,n,k]*s_service[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])

        print("slave dual objective value")
        print(dual_optimal)
        UB=min(
            UB,dual_optimal-sum([bar_x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])

        )
    master,bar_x,bar_y,bar_temp,stop = mp(Q_set,E_set,C_set,iter_i,params,cuts_type)
    print("bar_y")
    print(bar_y)
    #print("bar_x")
    #print(bar_x)
    print("master objective value")
    print(master.objVal)
    
    if stop:
        print("wrong master problem")
        break

    LB = master.objVal
    print("UB " + str(UB))
    print("LB " + str(LB))
endtime = datetime.datetime.now()  
print (endtime - starttime)
print("bar_y")
print(bar_y)    
#daigas=daigas(bar_y,params)        
