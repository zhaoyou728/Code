import numpy as np
from gurobipy import *
from collections import defaultdict
import random
import datetime
cuts_type="cb"
def read_data(filename):
    f=open(filename,"r")
    line=f.readline()
    items = line.split()
    num_fire_department=int(items[0])
    num_site=int(items[1])
    num_vehicle=int(items[2])
    num_layer=int(items[3])
#read i,j,n,k
    I=range(num_fire_department)
    J=range(num_site)
    K=range(num_vehicle)
    N=range(num_layer)
#read t[i,j]
    t_distance={}
    for i in I:
        line=f.readline()
        items = line.split()
        for j in J:
            t_distance[i,j]=int(items[j])
#read u[j]
    line=f.readline()
    items = line.split()
    u_call=[]
    for j in J:
        u_call.append(int(items[j]))
#read s[j]
    line=f.readline()
    items = line.split()
    s_service=[]
    for j in J:
        s_service.append(int(items[j]))
                
#read d[j]
    line=f.readline()
    items = line.split()
    d_demand=[]
    for j in J:
        d_demand.append(int(items[j]))
#read e[j]
    line=f.readline()
    items = line.split()
    e_setup=[]
    for j in J:
        e_setup.append(int(items[j]))
    
    bar_y = np.array([
        [1, 0, 0,1, 0, 0,1, 0, 0],
        [0, 0, 1,0, 0, 1,0, 0, 1],
        [0, 1, 0,0, 1, 0,0, 1, 0],
    ])
    bar=[]
    for j in range(num_site):
        for n in range(num_layer):
            for k in range(num_vehicle):
                bar.append(1)
    bar_x=np.array(bar).reshape((num_site,num_layer,num_vehicle))
    bar=[]
    for i in range(num_fire_department):
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    bar.append(random.randint(0,1))
        
    bar_temp=np.array(bar).reshape((num_fire_department,num_site,num_layer,num_vehicle))


    return bar_y,bar_x,bar_temp,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,e_setup



def mp(Q,E,iter_i,parameter,cuts_type):
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    e_setup = params["e_setup"] 
    stop = False
    print("======================== master problem ====================")
    master = Model("master")
    x=master.addVars(
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="x"
    )#GRB.BINARY
    y=master.addVars(
        [i for i in range(num_fire_department)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="y"

    )#,
    temp=master.addVars(
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )
    f = master.addVar(vtype=GRB.CONTINUOUS,name="f")

    master.addConstrs((
        quicksum(
            y[i,k] for i in range(num_fire_department)
        )==1
        for k in range(num_vehicle)

        ))

    master.addConstrs((
        quicksum(
            x[j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[j]
            for j in range(num_site)

        ))
    
    master.addConstrs((
        quicksum(
            x[j,n,k] for j in range(num_site)
            )<=1
            for n in range(num_layer) for k in range(num_vehicle)       

        ))
    
    master.addConstrs((
        quicksum(
            x[j,n,k] for n in range(num_layer)
        )<=1
            for j in range(num_site) for k in range(num_vehicle)

        ))
    master.addConstrs((
        y[i,k]+x[j,n,k]-1<=temp[i,j,n,k]
            for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))
    #################################################

    if cuts_type == "cb":
        for item in Q.values():

             
            master.addConstr(
                quicksum(y[i, k] for (i, k) in item[0]) +
                quicksum(1 - y[i, k] for (i, k) in item[1]) <= 2
            )
            master.addConstr(
                quicksum(x[j,n, k] for (j,n,k) in item[3]) +
                quicksum(1 - x[j,n, k] for (j,n,k) in item[4]) <=2
            )
            master.addConstr(
                quicksum(temp[i,j,n, k] for (i,j,n,k) in item[5]) +
                quicksum(1 - temp[i,j,n, k] for (i,j,n,k) in item[6]) <= 2
            )

    for item in E.values():
        master.addConstr(
 quicksum(
           [ item["l"][n,k]*temp[i,j,n,k]*t_distance[i,j] for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+quicksum(
               [item["u"][n,k]*x[j,n,k]*(u_call[j]+e_setup[j]) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+quicksum(
        [item["q"][n,k]*x[j,n,k]*e_setup[j] for j in range(num_site) for n in range(num_layer) if n>=1 for k in range(num_vehicle)])+quicksum(
[item["p"][n,k]*x[j,n,k]*s_service[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])<= f
        )
        
    
            
    master.setObjective(f-quicksum(
                        x[j,n,k]*u_call[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    master.update()
    master.relax()
    master.optimize()
   


    
    ################################################################
    bar_x = dict()
    bar_y = dict()
    bar_temp = dict()
    flag=False
    if master.status == GRB.OPTIMAL:
        flag=True
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                bar_y[i, k] = 1 if y[i,k].X >= 0.01 else 0
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    bar_x[j,n,k] = 1 if x[j,n,k].X >= 0.01 else 0
        for i in range(num_fire_department):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        bar_temp[i,j,n,k] = 1 if temp[i,j,n,k].X >= 0.01 else 0
        item = defaultdict(list)
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                if bar_y[i, k] > 0.01:
                    item[1].append((i, k))
                else:
                    item[0].append((i, k))
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    if bar_x[j,n,k] > 0.01:
                        item[4].append((j,n,k))
                    else:
                        item[3].append((j,n,k))
        for i in range(num_fire_department):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        if bar_temp[i,j,n,k] > 0.01:
                            item[6].append((i,j,n,k))
                        else:
                            item[5].append((i,j,n,k))
        Q[iter_i] = item
        
    else:
        print("There is no feasible solution in primal problem")
        stop = True
    return master,bar_x,bar_y,bar_temp,stop,flag

def relaxUB(model):
    mrelax = model.relax()
    model.optimize()
    return model.objval

def sp_cb(E,bar_x,bar_y,bar_temp,iter_i,parameter):
    
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    e_setup = params["e_setup"] 
    stop = False
   ####################################################
    print("="*20+ "sub problem with cb cuts" +"="*20)
    slave=Model("slave")
    c=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )
    con_l=slave.addConstrs((
        t_[n,k]>=quicksum(bar_temp[i,j,n,k]*t_distance[i,j] for i in range(num_fire_department) for j in range(num_site))
         for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_u=slave.addConstrs((
        c[n,k]>=quicksum(bar_x[j,n,k]*(u_call[j]+e_setup[j]) for j in range(num_site))
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_q=slave.addConstrs((
        c[n,k]>=w[n-1,k]+quicksum(bar_x[j,n,k]*e_setup[j] for j in range(num_site))
        for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    con_p=slave.addConstrs((
        z[n,k]>=v[n,k]+quicksum(bar_x[j,n,k]*s_service[j] for j in range(num_site))
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la1=slave.addConstrs((
        v[n,k]>=c[n,k]+t_[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la2=slave.addConstrs((
        w[n,k]>=z[n,k]+t_[n,k]

        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la3=slave.addConstrs((
        t_[n,k]>=0
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    slave.addConstrs((
        v[n,k]>=c[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    slave.addConstrs((
        z[n,k]>=v[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    slave.addConstrs((
        w[n,k]>=z[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))

                            

    slave.setObjective(quicksum(v[n,k] for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    slave.optimize()

    if slave.status == GRB.OPTIMAL:
        item = defaultdict(list)
        item["l"] = {k: v.pi for k, v in con_l.items()}
        item["u"] = {k: v.pi for k, v in con_u.items()}
        item["p"] = {k: v.pi for k, v in con_p.items()}
        item["q"] = {k: v.pi for k, v in con_q.items()}
        E[iter_i] = item
    else:
        print("wrong slave sub problem status" + str(daigas.status))
        stop = True
    return slave,stop


def daigas(bar_y,parameter):
    
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    e_setup = params["e_setup"] 
    stop = False
   ####################################################
    print("="*100+ "dasgas problem " +"="*100)
    daigas=Model("daigas")
    c=daigas.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )

    x=daigas.addVars(
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="x"
    )#GRB.BINARY
    temp=daigas.addVars(
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )


    daigas.addConstrs((
        quicksum(
            x[j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[j]
            for j in range(num_site)

        ))
    
    daigas.addConstrs((
        quicksum(
            x[j,n,k] for j in range(num_site)
            )<=1
            for n in range(num_layer) for k in range(num_vehicle)
            

        ))
    
    daigas.addConstrs((
        quicksum(
            x[j,n,k] for n in range(num_layer)
        )<=1
            for j in range(num_site) for k in range(num_vehicle)

        ))
    daigas.addConstrs((
        bar_y[i,k]+x[j,n,k]-1<=temp[i,j,n,k]
            for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))

    daigas.addConstrs((
        t_[n,k]>=quicksum(temp[i,j,n,k]*t_distance[i,j] for i in range(num_fire_department) for j in range(num_site))
         for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        c[n,k]>=quicksum(x[j,n,k]*(u_call[j]+e_setup[j]) for j in range(num_site))
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        c[n,k]>=w[n-1,k]+quicksum(x[j,n,k]*e_setup[j] for j in range(num_site))
        for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        z[n,k]>=v[n,k]+quicksum(x[j,n,k]*s_service[j] for j in range(num_site))
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        v[n,k]>=c[n,k]+t_[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        w[n,k]>=z[n,k]+t_[n,k]

        for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        t_[n,k]>=0
        for n in range(num_layer) for k in range(num_vehicle)
    ))
                            

    daigas.setObjective(quicksum(v[n,k] for n in range(num_layer) for k in range(num_vehicle))-quicksum(
                        x[j,n,k]*u_call[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    daigas.optimize()
    if slave.status == GRB.OPTIMAL:
        print(daigas.objval)
    
    return daigas

#main iteration
Q_set = dict()
E_set = dict()
C_set = dict()

LB = -1*1e10
UB = 1e10

warm_start = True
feasible_cnt = 0
optimal_cnt= 0
argvs=sys.argv
argc=len(argvs)
if (argc<=1):
    print("usage: #python %s filename" % argvs[0])
    quit()
bar_y,bar_x,bar_temp,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,e_setup=read_data(argvs[1])
params = dict()
params["num_fire_department"] = num_fire_department
params["num_site"] = num_site
params["num_vehicle"] = num_vehicle
params["num_layer"] = num_layer
params["t_distance"] = t_distance
params["u_call"] = u_call
params["s_service"] = s_service
params["d_demand"] = d_demand
params["e_setup"] = e_setup

starttime = datetime.datetime.now()



for iter_i in range(3):
    if np.abs(UB-LB) < 0.001:
        print("optimal")
        break
    print("="*100)
    print("iteration at" + str(iter_i))
    
    if cuts_type == "cb":
        slave,stop = sp_cb(E_set,bar_x,bar_y,bar_temp,iter_i,params)
    else:
        print("no available cuts type")
        break
    print("C  " + str(len(C_set.keys())))
    print("Q  " + str(len(Q_set.keys())))
    print("E  " + str(len(E_set.keys())))
    
    if stop:
        print("Wong slave problem")
        break

    item = E_set.get(iter_i, False)

    if item:
        print("slave objective value")
        print(slave.objVal)
        dual_optimal= sum(
            [ item["l"][n,k]*bar_temp[i,j,n,k]*t_distance[i,j] for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+sum(
            [item["u"][n,k]*bar_x[j,n,k]*(u_call[j]+e_setup[j]) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+sum(
            [item["q"][n,k]*bar_x[j,n,k]*e_setup[j] for j in range(num_site) for n in range(num_layer) if n>=1 for k in range(num_vehicle)])+sum(
            [item["p"][n,k]*bar_x[j,n,k]*s_service[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])

        print("slave dual objective value")
        print(dual_optimal)
        UB=min(
            UB,dual_optimal-sum([bar_x[j,n,k]*u_call[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])

        )
    master,bar_x,bar_y,bar_temp,stop,flag = mp(Q_set,E_set,iter_i,params,cuts_type)

    
    print("bar_y")
    print(bar_y)
    # print("bar_x")
    # print(bar_x)
    #print("bar_temp")
    #print(bar_temp)
    print("master objective value")
    print(master.objVal)

    if stop:
        print("wrong master problem")
        break

    LB = master.objVal

    print("UB " + str(UB))
    print("LB " + str(LB))
endtime = datetime.datetime.now()
print (endtime - starttime)
#daigas=daigas(bar_y,params)

        
