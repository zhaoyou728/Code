import numpy as np
from gurobipy import *
from collections import defaultdict
import datetime
import random
from matplotlib import pyplot as plt
cuts_type="general+cb"
def read_data(filename):
    f=open(filename,"r")
    line=f.readline()
    items = line.split()
    num_fire_department=int(items[0])
    num_site=int(items[1])
    num_vehicle=int(items[2])
    num_layer=int(items[3])
    num_s=int(items[4])
    #read i,j,n,k
    I=range(num_fire_department)
    J=range(num_site)
    K=range(num_vehicle)
    N=range(num_layer)
    S=range(num_s)
#read t[i,j]
    t_distance={}
    for s in S:
        for i in I:
            line=f.readline()
            items = line.split()
            for j in J:
                t_distance[s,i,j]=float(items[j])
#read u[j]

    u_call={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            u_call[s,j]=(int(items[j]))
#read s[j]

    s_service={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            s_service[s,j]=(int(items[j]))       
#read d[j]
    d_demand={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
             d_demand[s,j]=(int(items[j]))

#read M[j]


    big_M={}
    for s in S:
        line=f.readline()
        items = line.split()        
        for j in J:
            big_M[s,j]=(int(items[j]))
#read e[k]
    e_setup={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            e_setup[s,j]=(int(items[j]))


    return num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup

def daigas_low(bar_y,parameter):
    num_s=params["num_s"] 
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"]
    big_M=params["big_M"] 
    e_setup = params["e_setup"]
    stop = False
   ####################################################
    print("="*100+ "daigas sub problem " +"="*100)
    daigas=Model("daigas")
    c=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )

    x=daigas.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="x"
    )
    # y=daigas.addVars(
    #     [i for i in range(num_fire_department)],
    #     [k for k in range(num_vehicle)],
    #     vtype=GRB.BINARY, name="y"
    # )
    # daigas.addConstrs((
    #     quicksum(
    #         y[i,k] for i in range(num_fire_department)
    #     )==1
    #     for k in range(num_vehicle)

    #     ))
    temp=daigas.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )
    daigas.addConstrs((
        bar_y[i,k]+x[s,j,n,k]-1<=temp[s,i,j,n,k]
            for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))

    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))


    # daigas.addConstrs((
    #     t_[s,n,k]>=t_distance[s,i,j]-(1-x[s,j,n,k])*big_M[s,j]-(1-bar_y[i,k])*big_M[s,j]
    #     for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    # ))
    daigas.addConstrs((
        t_[s,n,k]>=quicksum(temp[s,i,j,n,k]*t_distance[s,i,j] for i in range(num_fire_department) for j in range(num_site))
         for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        c[s,n,k]>=quicksum(x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    
    daigas.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]

        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
                    

    daigas.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(
                        x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    daigas.optimize()
    return daigas.objVal

def initial(I,K):
    array={}
    for i in range(I):
        for k in range(K):
            array[i,k]=0
    for k in range(K):
        array[random.randint(1,10)% num_fire_department,k]=1
        #random.randint(1,10)% num_fire_department
    # for i in range(I):
    #      if sum(array[i,k] for k in range(num_vehicle))>=2:
    #          initial(I,K) 
            
    return array
######################
#   get the index       
######################
def get_index(left,right,number,array):
    for k in range(left,right):
        for i in range(number):
            if array[i,k]==1:
                return i

def swap_search(start,end,st_left,st_right,allocation):
    #num_fire_department+start-1  
    for k in range(st_left,st_right):
        for i in range(start,end):
            if allocation[(i)%num_fire_department,k]==1:
                allocation[(i)%num_fire_department,k],allocation[(i-1)%num_fire_department,k]=allocation[(i-1)%num_fire_department,k],allocation[(i)%num_fire_department,k]
#random.randint(1,num_vehicle-1)
    return allocation


argvs=sys.argv
argc=len(argvs)
if (argc<=1):
    print("usage: #python %s filename" % argvs[0])
    quit()
num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup=read_data(argvs[1])
params = dict()
params["num_fire_department"] = num_fire_department
params["num_site"] = num_site
params["num_vehicle"] = num_vehicle
params["num_layer"] = num_layer
params["num_s"] = num_s
params["t_distance"] = t_distance
params["u_call"] = u_call
params["s_service"] = s_service
params["d_demand"] = d_demand
params["big_M"] = big_M
params["e_setup"] = e_setup
               
######################
#    Initial              
######################
st_left=0
st_right=st_left+1
print(st_left,st_right)
iteration=0
best_allocation={}
new_allocation={}
starttime = datetime.datetime.now()
# new_allocation=initial(num_fire_department,num_vehicle)
# # initial_allocation=initial(num_fire_department,num_vehicle)
# solution=daigas_low(new_allocation,params)
# print(new_allocation)
# #best_allocation=allocation.copy()
# #Get the start point for the location of vehicle
# start=get_index(st_left,st_right,num_fire_department,new_allocation)
# end=start+1
# print(start,end)
flag=[]
set_solution_one=[]
set_solution_two=[]
######################
#    Loop    
######################
sequence=[]
for order in range(num_vehicle):
    sequence.append(order)
random.shuffle(sequence)
print(sequence)
star=False    
f=open("loca_search.log","w")
for it in range(1):
    best_allocation=initial(num_fire_department,num_vehicle)
    initial_allocation=best_allocation.copy()
    solution=daigas_low(best_allocation,params)
    initial_solution=solution
    f.write("The initial allocation:\n")
    f.write("{}\n".format(best_allocation))
    f.write("The initial solution:\n")
    f.write("{}\n".format(solution))
    print(best_allocation)
    set_solution_one.append(solution)
#Get the start point for the location of vehicle
    # start=get_index(st_left,st_right,num_fire_department,best_allocation)
    # end=start+1
    #print(start,end)
    for iter in sequence:#range(num_vehicle):
        st_left=iter
        st_right=st_left+1
        start=get_index(st_left,st_right,num_fire_department,best_allocation)
        end=start+1
        print(start,end)
#while True:
        print("*"*10+"local search start"+"*"*10)
        print("iteration at" + str(iteration))
        for it in range(num_fire_department-1):
        #Get the a new allocation by swap
            new_allocation=swap_search(start,end,st_left,st_right,best_allocation)
        #Get the number of vehicle in every fire departments
            for i in range(num_fire_department):
                flag.append(sum(new_allocation[i,k] for k in range(num_vehicle)))
            print("="*20)
            print(flag)
            print("="*20)
            if max(flag)<=num_vehicle:
            #Check the maximization number of vehicle in every fire department
            
                new_solution=daigas_low(new_allocation,params)
                if new_solution==solution:
                    star=True
                    break
                f.write("The new allocation is:\n")
                f.write("{}\n".format(new_allocation))
                f.write("The new solution is:\n")
                f.write("{}\n".format(new_solution))
                set_solution_one.append(new_solution)
                if new_solution < solution:
                    print("*"*20+"new solution"+"*"*20)
                    best_allocation=new_allocation.copy()
                    solution=new_solution
                    set_solution_two.append(solution)
                    #Update the vehicle
                    # st_left=(st_left+1)%num_vehicle#random.randint(1,10)%num_vehicle#
                    # st_right=st_left+1
                    # print(best_allocation)
                    # print(st_left,st_right)
                    start=get_index(st_left,st_right,num_fire_department,best_allocation)
                    print(start)
                    end=start+1
                    flag=[]
                    break
                
                else:
                    #Update the fire department
                    start=get_index(st_left,st_right,num_fire_department,new_allocation)
                    end=start+1
                    print(start,end)
            flag=[]
        if star==True:
            break
    if set_solution_two==[]:
        best_allocation=initial_allocation.copy()
        solution=initial_solution
        
    iteration=iteration+1
    f.write("The best allocation in {}\n".format(iteration))
    f.write("{}\n".format(best_allocation))
    f.write("The best solution in {}\n".format(iteration))
    f.write("{}\n".format(solution))
    print(best_allocation)
    print(solution)
#print(min(set_solution_two))
    ####################################################
    #temp=random.randint(1,10)%num_vehicle
    # st_left_one=random.randint(1,10)%num_vehicle
    # st_right_one=st_left_one+1
    # st_left_two=(st_left_one+1)%num_vehicle
    # st_right_two=st_left_two+1
    # best_allocation=initial(num_fire_department,num_vehicle)
    # initial_allocation=best_allocation.copy()
    # solution=daigas_low(best_allocation,params)
    # initial_solution=solution
    # start_one=get_index(st_left_one,st_right_one,num_fire_department,best_allocation)
    # end_one=start_one+1    
    # start_two=get_index(st_left_two,st_right_two,num_fire_department,best_allocation)
    # end_two=start_two+1
    # for a in range(3):        
    #     for itera in range(num_fire_department-1):
    #         new_allocation=swap_search(start_one,end_one,st_left,st_right,best_allocation)
    #         new_allocation=swap_search(start_two,end_two,st_left,st_right,new_allocation)
    #         for i in range(num_fire_department):
    #             flag.append(sum(new_allocation[i,k] for k in range(num_vehicle)))
    #             print("="*20)
    #             print(flag)
    #             print("="*20)
    #             new_solution=daigas_low(new_allocation,params)
    #             if new_solution < solution:
    #                 best_allocation=new_allocation.copy()
    #                 solution=new_solution
    #                 st_left_one=(st_left_one+1)%num_vehicle
    #                 st_right_one=st_left_one+1
    #                 st_left_two=(st_left_one+1)%num_vehicle
    #                 st_right_two=st_left_two+1
    #                 start_one=get_index(st_left_one,st_right_one,num_fire_department,best_allocation)
    #                 end_one=start_one+1    
    #                 start_two=get_index(st_left_two,st_right_two,num_fire_department,best_allocation)
    #                 end_two=start_two+1
    #                 flag=[]
    #                 break
    #         flag=[]
                
            
            
        
    
    
    # print(start,end)
    
    # #Update the vehicle
    # st_left=(st_left+1)%num_vehicle
    # st_right=st_left+1
    # iteration=iteration+1
    # if best_allocation=={}:
    #     best_allocation=initial_allocation.copy()
    #     #new_allocation=initial(num_fire_department,num_vehicle)
    #     #continue
    # print(best_allocation)
    # print(st_left,st_right)
    # start=get_index(st_left,st_right,num_fire_department,best_allocation)
    # print(start)
    # end=start+1
    # #The best allocation in this neighborhood as a initial point for next neighborhood
    # new_allocation={}
    # new_allocation=best_allocation.copy()



endtime = datetime.datetime.now()
print("Operation time is:")
print(endtime - starttime)            
print("Best objective solution is:")
print(solution)
print("Best allocation is:")
print(best_allocation)
print("set_solution_one")
print(set_solution_one)
print("set_solution_two")
print(set_solution_two)
plt.figure(1)
plt.subplot(211)
plt.plot(set_solution_one)
plt.subplot(212)
plt.plot(set_solution_two)
plt.show()







 
    # flag=[]#vehicle numbers in every fire department   
    # for k in range(st_left,st_right):
    #     for i in range(start,num_fire_department+start-1):
    #         if allocation[(i)%num_fire_department,k]==1:
    #             allocation[(i)%num_fire_department,k],allocation[(i+1)%num_fire_department,k]=allocation[(i+1)%num_fire_department,k],allocation[(i)%num_fire_department,k]
    #             for d in range(num_fire_department):
    #                 flag.append(sum(allocation[d,c] for c in range(num_vehicle)))
    #             print("="*10)
    #             print(flag)
    #             print("="*10)
    #             if max(flag)<2:
    #                 new_allocation=allocation
    #                 new_solution=daigas_low(new_allocation,params)
    #                 if new_solution < solution:
    #                     print("*"*20+"new solution"+"*"*20)
    #                     allocation=new_allocation 
    #                     solution=new_solution
    #             #     else:
    #             #         print("The best objective solution is:")
    #             #         print(solution)
    #             #         print("The best allocation is:")
    #             #         print(allocation)
    #             # else:
    #             #     continue
    #             flag=[]
        
    # st_left=(st_left+1)%num_vehicle
    # st_right=(st_left+1)%num_vehicle
