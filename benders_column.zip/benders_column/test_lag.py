import numpy as np
from gurobipy import *
from collections import defaultdict
import random
import datetime
cuts_type="cb"
example=1
if example==1:
    num_fire_department=2
    num_site=20
    num_vehicle=5
    num_layer=4
    t_distance=np.array([
        [30 ,35 ,35 ,20 ,30 ,26 ,20 ,39 ,28 ,31 ,30 ,32 ,25 ,28 ,30 ,25 ,20 ,29 ,30 ,21],
        [33 ,30 ,25 ,26 ,20 ,29 ,30 ,29 ,38 ,21 ,30 ,29 ,25 ,21 ,33 ,29 ,27 ,22 ,33 ,26],
 
    ])
    u_call= [0,120,75,170,250,300,390,500,520,600,650,560,700,720,750,800,850,875,900,1000];
    s_service = [15,18,20,23,20,20,25,29,24,28,20,25,29,24,28,24,29,24,20,25];
    d_demand = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1];
    big_M=[46,46,46,46,46,46];
    e_setup = [5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5];

    bar_y = np.array([
        [1, 1, 0,1,0],
        [0, 0, 1,0,1],
    ])

    bar=[]
    for j in range(num_site):
        for n in range(num_layer):
            for k in range(num_vehicle):
                bar.append(1)
    bar_x=np.array(bar).reshape((num_site,num_layer,num_vehicle))                           
    bar=[]
    for i in range(num_fire_department):
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    bar.append(1)
        
    bar_temp=np.array(bar).reshape((num_fire_department,num_site,num_layer,num_vehicle))

else:
    print("Example not found")
params = dict()
params["num_fire_department"] = num_fire_department
params["num_site"] = num_site
params["num_vehicle"] = num_vehicle
params["num_layer"] = num_layer
params["t_distance"] = t_distance
params["u_call"] = u_call
params["s_service"] = s_service
params["d_demand"] = d_demand
params["e_setup"] = e_setup

def mp(Q,E,iter_i,parameter,cuts_type):
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    e_setup = params["e_setup"] 
    stop = False
    print("======================== master problem ====================")
    master = Model("master")
    x=master.addVars(
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="x"
    )
    y=master.addVars(
        [i for i in range(num_fire_department)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="y"

    )#,
    temp=master.addVars(
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )
    f = master.addVar(vtype=GRB.CONTINUOUS,name="f")

    master.addConstrs((
        quicksum(
            y[i,k] for i in range(num_fire_department)
        )==1
        for k in range(num_vehicle)

        ))
    crelax=[]
    for j in range(num_site):
        crelax.append(master.addConstr(quicksum(x[j,n,k] for n in range(num_layer) for k in range(num_vehicle))==d_demand[j]))
        
    # master.addConstrs((
    #     quicksum(
    #         x[j,n,k] for n in range(num_layer) for k in range(num_vehicle)
    #     )==d_demand[j]
    #         for j in range(num_site)

    #     ))
    
    master.addConstrs((
        quicksum(
            x[j,n,k] for j in range(num_site)
            )<=1
            for n in range(num_layer) for k in range(num_vehicle)
            

        ))
    
    master.addConstrs((
        quicksum(
            x[j,n,k] for n in range(num_layer)
        )<=1
            for j in range(num_site) for k in range(num_vehicle)

        ))
    master.addConstrs((
        y[i,k]+x[j,n,k]-1<=temp[i,j,n,k]
            for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))
    #################################################
    print("==================local branch============================")

    if cuts_type == "cb":
        for item in Q.values():

            master.addConstr(
                quicksum(y[i, k] for (i, k) in item[0]) +
                quicksum(1 - y[i, k] for (i, k) in item[1]) <= 2
            )
            master.addConstr(
                quicksum(x[j,n, k] for (j,n,k) in item[3]) +
                quicksum(1 - x[j,n, k] for (j,n,k) in item[4]) <= 10
            )
            master.addConstr(
                quicksum(temp[i,j,n, k] for (i,j,n,k) in item[5]) +
                quicksum(1 - temp[i,j,n, k] for (i,j,n,k) in item[6]) <= 10
            )
    print("add cut ##########################################")

    for item in E.values():
        master.addConstr(
 quicksum(
           [ item["l"][n,k]*temp[i,j,n,k]*t_distance[i,j] for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+quicksum(
               [item["u"][n,k]*x[j,n,k]*(u_call[j]+e_setup[j]) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+quicksum(
        [item["q"][n,k]*x[j,n,k]*e_setup[j] for j in range(num_site) for n in range(num_layer) if n>=1 for k in range(num_vehicle)])+quicksum(
[item["p"][n,k]*x[j,n,k]*s_service[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])<= f
        )
    
            
    master.setObjective(f-quicksum(
                        x[j,n,k]*u_call[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    master.update()

    ########################## relax ################################
    same = 0.0
    samelimit=3
    norm = 0.1
    step = 0.0
    scale = 1.0
    xLB = 0.0
    xUB = 0.0
    xlambda = [0.0]*num_site
    slack = [0.0]*num_site

    xLB=relaxUB(master)
    xUB=2000
    # for n in range(num_layer):
    #     for k in range(num_vehicle):
    #         xUB+=1
    obj_original=f-quicksum(
                        x[j,n,k]*u_call[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle))
    lbmodel = 0
    print("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
    print(crelax)
    for ite in range(1):
        if lbmodel==0:
            lbmodel=1
            lenrelax=len(crelax)
            for b in range(lenrelax):
                master.remove(crelax[b])
            crelax=[]
            
        obj_lagrangian= quicksum(xlambda[j] * (d_demand[j] - \
                                               quicksum(x[j,n,k] for n in range(num_layer) for k in range(num_vehicle))) \
                                           for j in range(num_site))
        master.setObjective(obj_original+obj_lagrangian,GRB.MINIMIZE)
        master.optimize()
        # calculate 'slack'
        for j in range(num_site):
            slack[j]=sum(x[j,n,k].x for n in range(num_layer) for k in range(num_vehicle))- d_demand[j]
        # improve lower bound
        if master.objVal > xLB +1e-6:
            xLB=master.objVal
            same=0
        else:
            same+=1
        # update 'scale' if no improvement in 'samelimit' iteration
        if same == samelimit:
            scale/=2.0
            same=0
        # calculate 'norm'
        norm = sum(slack[j]**2.0 for j in range(num_site))
        # update 'step'
        step=scale*(xUB - master.objVal)/norm
        # update 'lambda'
        for j in range(num_site):
            if xlambda[j] > step*slack[j]:
                xlambda[j]-=step*slack[j]
            else:
                xlambda[j]= 0.0
        
        for j in range(num_site):
            crelax.append(master.addConstr(quicksum(x[j,n,k] for n in range(num_layer) for k in range(num_vehicle))==d_demand[j]))

        master.setObjective(obj_original, GRB.MINIMIZE)
        master.optimize()
        xUB=min(xUB,master.objVal)
        print("\n               *** Summary Report ***               \n")
        print(xLB)
        print(xUB)
        print(scale)
        print(step)


    
    ################################################################
    bar_x = dict()
    bar_y = dict()
    bar_temp = dict()
    flag=False
    if master.status == GRB.OPTIMAL:
        flag=True
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                bar_y[i, k] = 1 if y[i,k].X > 0.9 else 0
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    bar_x[j,n,k] = 1 if x[j,n,k].X > 0.9 else 0
        for i in range(num_fire_department):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        bar_temp[i,j,n,k] = 1 if temp[i,j,n,k].X > 0.3 else 0
        item = defaultdict(list)
        for i in range(num_fire_department):
            for k in range(num_vehicle):
                if bar_y[i, k] > 0.01:
                    item[1].append((i, k))
                else:
                    item[0].append((i, k))
        for j in range(num_site):
            for n in range(num_layer):
                for k in range(num_vehicle):
                    if bar_x[j,n,k] > 0.01:
                        item[4].append((j,n,k))
                    else:
                        item[3].append((j,n,k))
        for i in range(num_fire_department):
            for j in range(num_site):
                for n in range(num_layer):
                    for k in range(num_vehicle):
                        if bar_temp[i,j,n,k] > 0.01:
                            item[6].append((i,j,n,k))
                        else:
                            item[5].append((i,j,n,k))
        Q[iter_i] = item
        
    else:
        print("There is no feasible solution in primal problem")
        stop = True
    return master,bar_x,bar_y,bar_temp,stop,flag

def relaxUB(model):
    relax = model.relax()
    relax.optimize()
    return relax.objval

def sp_cb(E,bar_x,bar_y,bar_temp,iter_i,parameter):
    
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"] 
    e_setup = params["e_setup"] 
    stop = False
   ####################################################
    print("="*20+ "sub problem with cb cuts" +"="*20)
    slave=Model("slave")
    c=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=slave.addVars(
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )
    con_l=slave.addConstrs((
        t_[n,k]>=quicksum(bar_temp[i,j,n,k]*t_distance[i,j] for i in range(num_fire_department) for j in range(num_site))
         for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_u=slave.addConstrs((
        c[n,k]>=quicksum(bar_x[j,n,k]*(u_call[j]+e_setup[j]) for j in range(num_site))
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_q=slave.addConstrs((
        c[n,k]>=w[n-1,k]+quicksum(bar_x[j,n,k]*e_setup[j] for j in range(num_site))
        for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    con_p=slave.addConstrs((
        z[n,k]>=v[n,k]+quicksum(bar_x[j,n,k]*s_service[j] for j in range(num_site))
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la1=slave.addConstrs((
        v[n,k]>=c[n,k]+t_[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la2=slave.addConstrs((
        w[n,k]>=z[n,k]+t_[n,k]

        for n in range(num_layer) for k in range(num_vehicle)
    ))
    con_la3=slave.addConstrs((
        t_[n,k]>=0
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    slave.addConstrs((
        v[n,k]>=c[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    slave.addConstrs((
        z[n,k]>=v[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
    slave.addConstrs((
        w[n,k]>=z[n,k]
        for n in range(num_layer) for k in range(num_vehicle)
    ))
                            

    slave.setObjective(quicksum(v[n,k] for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    slave.optimize()

    if slave.status == GRB.OPTIMAL:
        item = dict()
        item["l"] = {k: v.pi for k, v in con_l.items()}
        item["u"] = {k: v.pi for k, v in con_u.items()}
        item["p"] = {k: v.pi for k, v in con_p.items()}
        item["q"] = {k: v.pi for k, v in con_q.items()}
        E[iter_i] = item
        print("Add Optimal cut")
    else:
        print("wrong slave sub problem status" + str(slave.status))
        stop = True
    return slave,stop

#main iteration
Q_set = dict()
E_set = dict()
C_set = dict()

LB = -1*1e10
UB = 1e10

warm_start = True
feasible_cnt = 0
optimal_cnt= 0
starttime = datetime.datetime.now()



for iter_i in range(3):
    if np.abs(UB-LB) < 0.001:
        print("optimal")
        break
    print("="*100)
    print("iteration at" + str(iter_i))
    
    if cuts_type == "cb":
        slave,stop = sp_cb(E_set,bar_x,bar_y,bar_temp,iter_i,params)
    else:
        print("no available cuts type")
        break
    print("C  " + str(len(C_set.keys())))
    print("Q  " + str(len(Q_set.keys())))
    print("E  " + str(len(E_set.keys())))
    
    if stop:
        print("Wong slave problem")
        break

    item = E_set.get(iter_i, False)

    if item:
        print("slave objective value")
        print(slave.objVal)
        dual_optimal= sum(
            [ item["l"][n,k]*bar_temp[i,j,n,k]*t_distance[i,j] for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+sum(
            [item["u"][n,k]*bar_x[j,n,k]*(u_call[j]+e_setup[j]) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])+sum(
            [item["q"][n,k]*bar_x[j,n,k]*e_setup[j] for j in range(num_site) for n in range(num_layer) if n>=1 for k in range(num_vehicle)])+sum(
            [item["p"][n,k]*bar_x[j,n,k]*s_service[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])

        print("slave dual objective value")
        print(dual_optimal)
        UB=min(
            UB,dual_optimal-sum([bar_x[j,n,k]*u_call[j] for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)])

        )
    master,bar_x,bar_y,bar_temp,stop,flag = mp(Q_set,E_set,iter_i,params,cuts_type)

    
    print("bar_y")
    print(bar_y)
    # print("bar_x")
    # print(bar_x)
    #print("bar_temp")
    #print(bar_temp)
    print("master objective value")
    print(master.objVal)

    if stop:
        print("wrong master problem")
        break

    LB = master.objVal

    print("UB " + str(UB))
    print("LB " + str(LB))
endtime = datetime.datetime.now()
print (endtime - starttime)
    

        
