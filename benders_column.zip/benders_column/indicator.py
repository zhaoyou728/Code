import numpy as np
from gurobipy import *
from collections import defaultdict
import datetime
import random
cuts_type="general+cb"
N_0={}
N_1={}
N_y={}
def read_data(filename):
    f=open(filename,"r")
    line=f.readline()
    items = line.split()
    num_fire_department=int(items[0])
    num_site=int(items[1])
    num_vehicle=int(items[2])
    num_layer=int(items[3])
    num_s=int(items[4])
    #read i,j,n,k
    I=range(num_fire_department)
    J=range(num_site)
    K=range(num_vehicle)
    N=range(num_layer)
    S=range(num_s)
#read t[i,j]
    t_distance={}
    for s in S:
        for i in I:
            line=f.readline()
            items = line.split()
            for j in J:
                t_distance[s,i,j]=float(items[j])
#read u[j]

    u_call={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            u_call[s,j]=(int(items[j]))
#read s[j]

    s_service={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            s_service[s,j]=(int(items[j]))       
#read d[j]
    d_demand={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
             d_demand[s,j]=(int(items[j]))

#read M[j]


    big_M={}
    for s in S:
        line=f.readline()
        items = line.split()        
        for j in J:
            big_M[s,j]=(int(items[j]))
#read e[k]
    e_setup={}
    for s in S:
        line=f.readline()
        items = line.split()
        for j in J:
            e_setup[s,j]=(int(items[j]))


    return num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup

def daigas_low(parameter):
    num_s=params["num_s"] 
    num_fire_department = params["num_fire_department"] 
    num_site = params["num_site"] 
    num_vehicle = params["num_vehicle"] 
    num_layer = params["num_layer"] 
    t_distance = params["t_distance"] 
    u_call = params["u_call"]
    s_service = params["s_service"] 
    d_demand = params["d_demand"]
    big_M=params["big_M"] 
    e_setup = params["e_setup"]
    stop = False
   ####################################################
    print("="*100+ "daigas sub problem " +"="*100)
    daigas=Model("daigas")
    c=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="c"
    )
    t_=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="t_"
    )
    z=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="z"
    )
    w=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="w"
    )
    v=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="v"
    )
    delay=daigas.addVars(
        [s for s in range(num_s)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.CONTINUOUS, name="delay"
    )

    x=daigas.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        ub=1,lb=0,vtype=GRB.CONTINUOUS, name="x"
    )

    x=daigas.addVars(
        [s for s in range(num_s)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="x"
    )
    # y=daigas.addVars(
    #     [i for i in range(num_fire_department)],
    #     [k for k in range(num_vehicle)],
    #     ub=1,lb=0,vtype=GRB.CONTINUOUS, name="y"
    # )
    y=daigas.addVars(
        [i for i in range(num_fire_department)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY, name="y"
    )
    temp=daigas.addVars(
        [s for s in range(num_s)],
        [i for i in range(num_fire_department)],
        [j for j in range(num_site)],
        [n for n in range(num_layer)],
        [k for k in range(num_vehicle)],
        vtype=GRB.BINARY,name="temp"

    )
    daigas.addConstrs((
        y[i,k]+x[s,j,n,k]-1<=temp[s,i,j,n,k]
            for s in range(num_s) for i in range(num_fire_department) for j in range(num_site)  for n in range(num_layer) for k in range(num_vehicle)

        ))
    daigas.addConstrs((
        quicksum(
            y[i,k] for i in range(num_fire_department)
        )==1
        for k in range(num_vehicle)

        ))

    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer) for k in range(num_vehicle)
        )==d_demand[s,j]
            for s in range(num_s) for j in range(num_site)

        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for j in range(num_site)
            )<=1
            for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
        ))
    
    daigas.addConstrs((
        quicksum(
            x[s,j,n,k] for n in range(num_layer)
        )<=1
            for s in range(num_s) for j in range(num_site) for k in range(num_vehicle)

        ))
    daigas.addConstrs((
        t_[s,n,k]>=quicksum(temp[s,i,j,n,k]*t_distance[s,i,j] for i in range(num_fire_department) for j in range(num_site))
         for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))

    # daigas.addConstrs((
    #     t_[s,n,k]>=t_distance[s,i,j]-(1-x[s,j,n,k])*big_M[s,j]-(1-y[i,k])*big_M[s,j]
    #     for s in range(num_s) for i in range(num_fire_department) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)
    # ))

    daigas.addConstrs((
        c[s,n,k]>=quicksum(x[s,j,n,k]*(u_call[s,j]+e_setup[s,j]) for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    
    daigas.addConstrs((
        c[s,n,k]>=w[s,n-1,k]+quicksum(x[s,j,n,k]*e_setup[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) if n>=1 for k in range(num_vehicle)
    ))

    daigas.addConstrs((
        z[s,n,k]>=v[s,n,k]+quicksum(x[s,j,n,k]*s_service[s,j] for j in range(num_site))
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        v[s,n,k]>=c[s,n,k]+t_[s,n,k]
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        w[s,n,k]>=z[s,n,k]+t_[s,n,k]

        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    daigas.addConstrs((
        t_[s,n,k]>=0
        for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)
    ))
    # for s in range(num_s):
    #     for j in range(num_site):
    #         for n in range(num_layer) :
    #             for k in range(num_vehicle):
    #                 daigas.addConstr((x[s,j,n,k]==1)>>(
    #                     delay[s,n,k]==v[s,n,k]-u_call[s,j]))
    
    # daigas.setObjective(quicksum(delay[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    daigas.setObjective(quicksum(v[s,n,k] for s in range(num_s) for n in range(num_layer) for k in range(num_vehicle))-quicksum(x[s,j,n,k]*u_call[s,j] for s in range(num_s) for j in range(num_site) for n in range(num_layer) for k in range(num_vehicle)),GRB.MINIMIZE)
    daigas.optimize()
    
    return daigas

argvs=sys.argv
argc=len(argvs)
if (argc<=1):
    print("usage: #python %s filename" % argvs[0])
    quit()
num_s,num_fire_department,num_site,num_vehicle,num_layer,t_distance,u_call,s_service,d_demand,big_M,e_setup=read_data(argvs[1])
params = dict()
params["num_fire_department"] = num_fire_department
params["num_site"] = num_site
params["num_vehicle"] = num_vehicle
params["num_layer"] = num_layer
params["num_s"] = num_s
params["t_distance"] = t_distance
params["u_call"] = u_call
params["s_service"] = s_service
params["d_demand"] = d_demand
params["big_M"] = big_M
params["e_setup"] = e_setup
daigas=daigas_low(params)
