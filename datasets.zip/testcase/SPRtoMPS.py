from scipy.sparse import find
import numpy as ny
from math import log10
from math import ceil


# transform matrix_format problem to mps_format problem
def sprtomps(filename, c, a1, b1, a2, b2, lb, ub):
    maxp = 1000
    m1 = a1.shape[0]
    n = a1.shape[1]
    m2 = a2.shape[0]
    [ii1, jj1, kk1] = find(a1)
    ii1 = ny.array(ii1) + 1
    jj1 = ny.array(jj1) + 1
    size1 = ii1.shape[0]
    [ii2, jj2, kk2] = find(a2)
    ii2 = ny.array(ii2) + 1
    jj2 = ny.array(jj2) + 1
    size2 = ii2.shape[0]

    f = open(filename, 'w')

    f.write('NAME          NO\n')

    f.write('ROWS\n')
    f.write(' N  obj\n')
    for i in range(1, m1 + 1):
        f.write(' L  row%d\n' % i)
    for i in range(1, m2 + 1):
        f.write(' E  row%d\n' % int(i + m1))

    f.write('COLUMNS\n')
    z1 = int(0)
    z2 = int(0)
    for j in range(1, n + 1):
        width = log10(j)
        if ceil(width) == width:
            cksp = width + 1
        else:
            cksp = ceil(width)
        cksp = int(10 - cksp - 3)

        f.write('    col%d' % j)
        for i in range(cksp):
            f.write(' ')
        f.write('obj       %.5f\n' % c[j - 1])

        while z1 < size1 and jj1[z1] == j:
            f.write('    col%d' % j)
            for i in range(cksp):
                f.write(' ')

            width = log10(ii1[z1])
            if ceil(width) == width:
                rksp = width + 1
            else:
                rksp = ceil(width)
            rksp = int(10 - 3 - rksp)
            f.write('row%d' % ii1[z1])
            for i in range(rksp):
                f.write(' ')
            f.write('%.5f\n' % kk1[z1])
            z1 = z1 + 1

        while z2 < size2 and jj2[z2] == j:
            f.write('    col%d' % j)
            for i in range(cksp):
                f.write(' ')

            width = log10(ii2[z2] + m1)
            if ceil(width) == width:
                rksp = width + 1
            else:
                rksp = ceil(width)
            rksp = int(10 - 3 - rksp)
            f.write('row%d' % (int(ii2[z2]) + m1))
            for i in range(rksp):
                f.write(' ')
            f.write('%.5f\n' % kk2[z2])
            z2 = z2 + 1

    f.write('RHS\n')
    for i in range(1, 1 + m1):
        if abs(b1[i - 1]) > 1.e-10:
            f.write('    rhs       ')
            width = log10(i)
            if ceil(width) == width:
                rksp = width + 1
            else:
                rksp = ceil(width)
            rksp = int(10 - 3 - rksp)
            f.write('row%d' % i)
            for j in range(rksp):
                f.write(' ')
            f.write('%.5f\n' % b1[i - 1])

    for i in range(1, 1 + m2):
        if abs(b2[i - 1]) > 1.e-10:
            f.write('    rhs       ')
            width = log10(i + m1)
            if ceil(width) == width:
                rksp = width + 1
            else:
                rksp = ceil(width)
            rksp = int(10 - 3 - rksp)
            f.write('row%d' % int(i + m1))
            for j in range(rksp):
                f.write(' ')
            f.write('%.5f\n' % b2[i - 1])

    f.write('BOUNDS\n')
    for j in range(1, 1 + n):
        if abs(lb[j - 1]) <= 1.e-10 and ub[j - 1] >= maxp:
            continue

        width = log10(j)
        if ceil(width) == width:
            cksp = width + 1
        else:
            cksp = ceil(width)
        cksp = int(10 - cksp - 3)

        if lb[j - 1] <= -maxp and ub[j - 1] >= maxp:
            f.write(' FR BOUNDS    col%d \n' % j)
            continue

        if ub[j - 1] >= maxp:
            # print(' PL %d'%j)
            f.write(' PL BOUNDS    col%d' % j)
            for i in range(cksp):
                f.write(' ')
            f.write('%g\n' % lb[j - 1])
            continue
        if lb[j - 1] <= -maxp:
            # print(' MI %d' % j)
            f.write(' MI BOUNDS    col%d' % j)
            for i in range(cksp):
                f.write(' ')
            f.write('%g\n' % ub[j - 1])
            continue

        # rangeBOUNDS
        # print(' RG %d %.5f %.5f'%(j,lb[j-1],ub[j-1]))
        f.write(' LO BOUNDS    col%d' % j)
        for i in range(cksp):
            f.write(' ')
        f.write('%g\n' % lb[j - 1])
        f.write(' UP BOUNDS    col%d' % j)
        for i in range(cksp):
            f.write(' ')
        f.write('%g\n' % ub[j - 1])

    f.write('ENDATA')
    f.close()
    print('Formulate mps File,OK')
