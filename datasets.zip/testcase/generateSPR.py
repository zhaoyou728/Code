# -*- coding: UTF-8 -*-
from __future__ import print_function
import random as rd
import numpy as ny
from math import ceil
from scipy import sparse
import copllp as lp
from SPRtoMPS import sprtomps


MP = lp.INF
density = 0.1
m1 = int(50)

m2 = int(ceil(m1 * (rd.random())))
n = int(m1 + m2)
x0 = ny.zeros((n, 1))
L = ny.zeros((n, 1))
U = ny.ones((n, 1)) * MP

# give variables  random bounds
for i in range(n):
    if rd.random() > 0.5:
        idd = ceil(rd.random() * 6)
        if idd == 1:
            L[i] = -MP
        if idd == 1:
            L[i] = rd.uniform(-1000, 1000)
            x0[i] = L[i]+10
        if idd == 3:
            L[i] = -MP
            U[i] = rd.uniform(-1000, 1000)
            x0[i] = U[i] - 10.
        if idd == 4:
            U[i] = rd.uniform(-1000, 1000)
            L[i] = U[i]
            x0[i] = L[i]
        if idd == 5:
            tem = ny.random.random([2, 1]) * 2000 - 1000
            L[i] = min(tem)
            U[i] = max(tem)
            x0[i] = (L[i]+U[i])/2

A1 = sparse.rand(m1, n, density, 'coo', ny.float64)
A2 = sparse.rand(m2, n, density, 'coo', ny.float64)
b1 = A1 * x0 + ny.random.random(size=(m1, 1))*5
b2 = A2 * x0

y1 = ny.random.random(size=(m1, 1))*2-2
y2 = ny.random.random(size=(m2, 1))*2-1
c = A1.T * y1 + A2.T * y2
for i in range(n):
    if L[i] <= -MP and U[i] < MP:
        c[i] = c[i] - 10
    if L[i] > -MP and U[i] >= MP:
        c[i] = c[i] + 10

print('SPARSE (%d+%d) * %d, ok' % (m1, m2, n))


mpsfile = b'example.mps'
sprtomps(mpsfile, c, A1, b1, A2, b2, L, U)
# mpsfile = b'C:/Danny/Files/netlib/80BAU3B.SIF'

res = lp.linprg(mpsfile)
# res = lp.linprg(c,A1,b1,A2,b2,L,U)
res = lp.linprg(obj = c,Aineq = A1,bineq = b1,Aeq = A2,beq = b2,lb = L,ub = U)
# res = lp.linprg(obj = c,Aineq = A1,bineq = b1,lb = L,ub = U)
# res = lp.linprg(obj = c,Aeq = A2,beq = b2,lb = L,ub = U)

res.keys()