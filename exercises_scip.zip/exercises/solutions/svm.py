
from pyscipopt import Model, quicksum
from data.load_cancer import load_cancer
import numpy as np
import random
import math


#############    Get user input
#############################################################################

mode = "linear" # mode is in ['linear', 'sparse']

# sparsity of classifier: percentage of present features not being used for classification
sparsity = .2  # between 0.0 and 1.0 (1: all features are used, 0: none are used)

# C is a regularization parameter
C = 10.0 # positive float

# set the bounds for the weights. Weights will be between [-weightBound, weightBound]
weightBound = 100.0 # positive float
# set these to [1.0, 1.0] if you don't want to manually balance anything
balance = [1.0, 1.0] # list of length 2

# set the time limit
tLim = 60.0 # positive float

# use 60 % of the available samples for training
n_train = math.ceil(569 * 0.6)

#############    Load data
#############################################################################

# get data
dataset = load_cancer()
X_orig = np.array(dataset.data)
Y_orig = np.array(dataset.targets)

#############    Initialize variables
#############################################################################

nfeatures = len(X_orig[0]) # number of features (dimension of space)
n = len(Y_orig)

# change the random seed for a different training/test split.
random.seed(2018)
randnums = random.sample(range(n), n_train)

# use a random selection of n_train data points for training
X = X_orig[randnums]
Y = Y_orig[randnums]
nexamples = len(Y) # number of training examples

diff = [m for m in range(n) if m not in randnums]

X_predict = X_orig[diff]
Y_predict = Y_orig[diff]

n = len(Y_predict)

#############    Model
#############################################################################

# create model
model = Model("SCIP-SVM")
# set timelimit
model.setRealParam("limits/time", tLim)

#############    Add problem variables
#############################################################################

omegas = []
# add weight variables and offset variable (as last one)
for f in range(nfeatures + 1):
    omegas.append(model.addVar(vtype='C',
                               name="omega_%d" % f,
                               ub = weightBound,
                               lb = -weightBound))

xis = []
# add variables xi to penalize misclassification
for x in range(nexamples):
    xis.append(model.addVar(vtype='C',
                            name="psi_%d" %x))

#############    Add variable for objective function
#############################################################################

# add variable for objective function, since objective function is not linear.
objvar = model.addVar(vtype='C',
                      name="objective",
                      obj=1.0)

# apply correction to account for unequal proportions of positive and negative examples
balance_coeffs = [balance[0 if yi == -1 else 1] for yi in Y]

model.addCons(quicksum(.5 *omegas[f]*omegas[f] for f in range(nfeatures)) \
                   + quicksum(C / float(nexamples) * balance_coeffs[x] * xis[x] for x in range(nexamples))
                   - objvar <= 0,
              name="objective_function")

#############    Add model formulation
#############################################################################

# do this for linear and sparse model
for x in range(nexamples):
    model.addCons(Y[x] * (quicksum(X[x][f] * omegas[f] for f in range(nfeatures)) + omegas[nfeatures]) >= + 1 - xis[x],
                  name="example_%d"%x)

# sparse model ensures that only a certain number of features are selected
if mode == "sparse":
    vs = []
    for f in range(nfeatures):
        vs.append(model.addVar(vtype='B', name="v_%d" % f))
        model.addCons(omegas[f] <=  weightBound * vs[f],
                      name="upper_vbound_%d"%f)
        model.addCons(omegas[f] >= -weightBound * vs[f],
                      name="lower_vbound_%d"%f)

    model.addCons(quicksum(vs[f] for f in range(nfeatures)) <= int(sparsity * nfeatures),
                  name="sparsity")

#############    Solve / optimize
#############################################################################

model.optimize()

sols = model.getSols()
if not sols:
    print("Could not find solutions, exiting.")
    exit(0)

weights = [model.getSolVal(sols[0], omegas[f]) for f in range(nfeatures)]
offset = model.getSolVal(sols[0], omegas[nfeatures])
primalbound = model.getPrimalbound()

#############    Predict
#############################################################################

pairs = np.array(list(zip(X_predict, Y_predict)))
signed_penalties = list(map(
        lambda x:
            (x[1]*max(0, 1 - (offset + sum(weights[f] * x[0][f] for f in range(nfeatures)))*x[1])),
        pairs))

n_true_positives = sum([1 if signed_penalties[i] == 0 and  Y_predict[i] == 1 else 0 for i in range(n)])
n_true_negatives = sum([1 if signed_penalties[i] == 0 and  Y_predict[i] == -1 else 0 for i in range(n)])
n_false_positives = sum([1 if signed_penalties[i] > 0 and  Y_predict[i] == 1 else 0 for i in range(n)])
n_false_negatives = sum([1 if signed_penalties[i] < 0 and  Y_predict[i] == -1 else 0 for i in range(n)])
n_wrong_class = n_false_negatives + n_false_positives

print("")
print("RESULTS:")
print("")
print("mode = {}".format(mode))
print("sparsity = {}".format(sparsity))
print("C = {}".format(C))
print("weightBound = {}".format(weightBound))
print("balance = {}".format(balance))
print("tlim = {}".format(tLim))
print("")
print("Trained on {} datapoints".format(len(Y)))
print("Predicted on {} datapoints".format(n))
print("")
print("W = {}".format(weights))
print("b = {}".format(offset))
print("obj = {}".format(primalbound))
print("")
print("Number of missclassifications: {} out of {} ({} %)".format(n_wrong_class, n,100*n_wrong_class/n))
print("Number of false positives: {} out of {} ({} %)".format(n_false_positives, n_true_negatives + n_false_positives, 100*n_false_positives/(n_true_negatives + n_false_positives)))
print("Number of false negatives: {} out of {} ({} %)".format(n_false_negatives,
                                                              n_false_negatives + n_true_positives, 100*n_false_negatives/(n_false_negatives + n_true_positives)))
