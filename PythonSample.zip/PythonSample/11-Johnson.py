﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
import numpy as np
def Johnson(p):
    """
    ジョンソン法
        2台のフローショップ型のジョブスケジュールを求める
    入力
        p: (前工程処理時間, 後工程処理時間)の製品ごとのリスト
    出力
        処理時間と処理順のリスト
    """
    a, l1, l2 = np.array(p, dtype=float).flatten(), [], [] # step 1
    for i in range(a.size // 2):
        j = a.argmin() # step 2
        k = j // 2
        if j % 2 == 0:
            l1.append(k) # step 3
        else:
            l2.append(k) # step 4
        a[2 * k] = a[2 * k + 1] = np.inf
    l = l1 + l2[::-1]
    return proctime(p, l), l # step 5

def proctime(p, l):
    n = len(p)
    t = [[0, 0] for i in range(n + 1)]
    for i in range(1, n + 1):
        t1, t2 = p[l[i - 1]]
        t[i][0] = t[i - 1][0] + t1
        t[i][1] = max(t[i - 1][1], t[i][0]) + t2
    return t[n][1]

from itertools import permutations
def Johnson2(p):
    ll = list(permutations(range(len(p))))
    tt = [proctime(p, l) for l in ll]
    i = np.argmin(tt)
    return tt[i], ll[i]

if __name__ == '__main__':
    np.random.seed(1)
    for i in range(100): # 100回繰り返す
        p = np.random.randint(1, 1000, (6, 2))
        if Johnson(p)[0] != Johnson2(p)[0]: # 総当り(Johnson2)と比較
            print('NG')
            break
    else:
        print('All OK')