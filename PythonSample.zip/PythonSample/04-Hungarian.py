﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
"""
import networkx as nx
import numpy as np
from itertools import combinations
def Hungarian(g):
    """
    ハンガリー法
        完全2部グラフの最大重み完全マッチングを求める
    入力
        g: NetworkXのグラフ(重みは'weight'属性とする)
    出力
        マッチングをなす辺のリスト
    """
    n = g.number_of_nodes() // 2
    r = range(n)
    assert(g.number_of_nodes() == 2 * n and g.number_of_edges() == n * n and
           nx.bipartite.is_bipartite_node_set(g, r))
    # r の部分集合
    p = [[(list(j), list(set(r) - set(j))) for j in combinations(r, i + 1)] for i in range(n)]
    a = np.array([[g.adj[i][j + n]['weight'] for j in r] for i in r]) # step 1
    a = a.max() - a # step 1
    a -= a.min(axis=1, keepdims=True) # step 1
    a -= a.min(axis=0, keepdims=True) # step 1
    while True:
        g2 = nx.Graph() # step 2
        g2.add_nodes_from(range(2 * n)) # step 2
        g2.add_edges_from((i, j + n) for i in r for j in r if a[i][j] < 1e-8) # step 2
        m = np.array(list({(min(i), max(i)) for i in nx.max_weight_matching(g2).items()})) # step 2
        if len(m) == n: return m.tolist() # step 2
        HungarianSub(n, p, a) # step 3 & 4

def HungarianSub(n, p, a):
    """しらみつぶしに調べているので効率は悪い"""
    for i in range(1, n * 2):
        for j in range(i + 1):
            for id1 in p[n - j - 1]:
                for id2 in p[n - i + j - 1]:
                    f = np.repeat(id1[0], len(id2[0])), id2[0] * len(id1[0])
                    mn = a[f].min()
                    if mn > 0:
                        h = np.repeat(id1[1], len(id2[1])), id2[1] * len(id1[1])
                        a[f] -= mn
                        a[h] += mn
                        return

if __name__ == '__main__':
    np.random.seed(1)
    n = 5
    r, r2 = range(n), range(n, 2 * n)
    for i in range(100): # 100回繰り返す
        g = nx.Graph()
        g.add_nodes_from(range(2 * n))
        g.add_weighted_edges_from((i, j, int(np.random.random() * 100)) for i in r for j in r2)
        a = np.array([[g.adj[i][j + n]['weight'] for j in r] for i in r])
        if abs(sum([a[i, j - n] for i, j in Hungarian(g)]) -
               sum([a[i, j - n] for i, j in nx.max_weight_matching(g).items() if j >= n])) > 1e-6: # NetworkXと比較
            print('NG')
            break
    else:
        print('All OK')