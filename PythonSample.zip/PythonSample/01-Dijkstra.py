﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
import networkx as nx
import numpy as np
def Dijkstra(g, s, t):
    """
    ダイクストラ法
        2点間の最短距離を求める
    入力
        g: NetworkXのグラフ(距離は'weight'属性とする)
        s: 始点
        t: 終点
    出力
        距離
    """
    d = np.array([np.inf] * g.number_of_nodes()) # step 1
    b = np.array([False] * g.number_of_nodes()) # step 1
    d[s] = 0 # step 2
    while not b[t]: # step 3
        i = (d + (b*1e100)).argmin() # step 4
        if np.isinf(d[i]): break # step4
        b[i] = True # step 4
        for j in g.neighbors(i): # step 4
            d[j] = min(d[j], d[i] + g.adj[i][j].get('weight', 1)) # step 4
    return d[t]

if __name__ == '__main__':
    nx.random_graphs.random.seed(1)
    for i in range(100): # 100回繰り返す
        while True:
            g = nx.random_graphs.fast_gnp_random_graph(20, 0.1) # ノード数20のランダムなグラフ
            if nx.connected.is_connected(g): # 連結の場合
                for j, k in g.edges():
                    g.adj[j][k]['weight'] = nx.random_graphs.random.random() # 距離を設定
                break
        if Dijkstra(g, 0, 1) != nx.dijkstra_path_length(g, 0, 1): # NetworkXと比較
            print('NG')
            break
    else:
        print('All OK')