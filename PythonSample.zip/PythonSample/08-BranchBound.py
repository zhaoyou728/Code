﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
def BranchBound(w, p, c):
    """
    ナップサック問題の分枝限定法
        価値の高いものから決定していく
    入力
        w: 大きさのリスト
        p: 価値のリスト
        c: ナップサックの大きさ
    出力
        最適値(価値)
    """
    l = [(p0 / w0, p0, w0) for p0, w0 in zip(p, w)]
    l.sort(reverse=True)
    l = [(p0, w0) for pw, p0, w0 in l]
    lb = BranchBoundGreedy(l, c) # 下界
    return BranchBoundSub(l, c, 0, lb)

def BranchBoundSub(l, c, fx, lb):
    """
    ナップサック問題の分枝限定法
        価値の高いものから決定していく
    入力
        l: (価値, 大きさ)のリスト
        c: ナップサックの大きさ
        fx: 既に入れている分の価値
        lb: 下界
    出力
        下界
    """
    if len(l) == 0: return fx
    u1 = BranchBoundRelax(l[1:], c - l[0][1]) + l[0][0] if l[0][1] <= c else 0 # 先頭を入れる
    u2 = BranchBoundRelax(l[1:], c) # 先頭を入れない
    if u1 + fx > lb and l[0][1] <= c:
        l1 = BranchBoundSub(l[1:], c - l[0][1], fx + l[0][0], lb)
        if l1 > lb: lb = l1
    if u2 + fx > lb:
        l2 = BranchBoundSub(l[1:], c, fx, lb)
        if l2 > lb: lb = l2
    return lb

def BranchBoundGreedy(l, c):
    """
    ナップサック問題の貪欲法
        価値の高いものからいれる
    入力
        l: (価値, 大きさ)のリスト
        c: ナップサックの大きさ
    出力
        下界
    """
    result = 0
    for p0, w0 in l:
        if w0 <= c:
            result += p0
            c -= w0
    return result

def BranchBoundRelax(l, c):
    """
    ナップサック問題の貪欲法
        価値の高いものから連続緩和していれる
    入力
        l: (価値, 大きさ)のリスト
        c: ナップサックの大きさ
    出力
        緩和解の値
    """
    result = 0
    for p0, w0 in l:
        t = min(c, w0)
        result += p0 / w0 * t
        c -= t
    return result

def KnapsackByCache(w, p, c, cache={}):
    """
    ナップサック問題の動的最適化法
        キャッシュを用いるトップダウン(Python3ならばfunctools.lru_cacheが使える)
    入力
        w: 大きさのリスト
        p: 価値のリスト
        c: ナップサックの大きさ
    出力
        最適値(価値)
    """
    if len(w) == 0: return 0
    if (w, p, c) in cache: return cache[(w, p, c)]
    result = max(KnapsackByCache(w[:-1], p[:-1], c),
                 KnapsackByCache(w[:-1], p[:-1], c - w[-1]) + p[-1] if c >= w[-1] else 0)
    cache[(w, p, c)] = result
    return result

if __name__ == '__main__':
    import random
    random.seed(1)
    n, c = 10, 50
    for i in range(100): # 100回繰り返す
        w = tuple(random.randint(4, 10) for i in range(n))
        p = tuple(w[i] + random.randint(-3, 3) for i in range(n))
        if BranchBound(w, p, c) != KnapsackByCache(w, p, c):
            print('NG')
            break
    else:
        print('All OK')