﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
import networkx as nx
def Kruskal(g):
    """
    クラスカル法
        無向グラフの最小全域木を求める
    入力
        g: NetworkXのグラフ(連結で、重みは'weight'属性とする)
    出力
        最小全域木をなす辺のリスト
    """
    T = nx.Graph() # step 1
    E = [(g.get_edge_data(i, j).get('weight', 1), i, j) for i, j in g.edges()] # step 1
    E.sort(reverse=True) # step 1
    while E: # step 2
        w, i, j = E.pop() # step 2
        T.add_edge(i, j) # step 3
        if nx.cycle_basis(T): # step 3
            T.remove_edge(i, j) # step 3
        if g.number_of_nodes() == T.number_of_nodes() and nx.is_connected(T): # step 4
            return T.edges() # step 4

if __name__ == '__main__':
    nx.random_graphs.random.seed(1)
    for i in range(100): # 100回繰り返す
        while True:
            g = nx.random_graphs.fast_gnp_random_graph(20, 0.1) # ノード数20のランダムなグラフ
            if nx.connected.is_connected(g): # 連結の場合
                for j, k in g.edges():
                    g.get_edge_data(j, k)['weight'] = nx.random_graphs.random.random() # 距離を設定
                break
        s = {(i, j) for i, j, d in nx.minimum_spanning_edges(g)}
        if set(Kruskal(g)) != s: # NetworkXと比較
            print('NG')
            break
    else:
        print('All OK')