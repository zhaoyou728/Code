﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
from itertools import permutations
from random import shuffle
def MultiStartLocalSearch(w, p, c):
    """
    ナップサック問題の多スタート局所探索法
    入力
        w: 大きさのリスト
        p: 価値のリスト
        c: ナップサックの大きさ
    出力
        最適値(価値)
    """
    l = [(p0, w0) for p0, w0 in zip(p, w)]
    result = -1
    for i in range(10):
        r = MultiStartLocalSearchSub(list(l), c)
        if r > result: result = r
        shuffle(l)
    return result

def MultiStartLocalSearchSub(l, c):
    """
    ナップサック問題の局所探索法
        挿入近傍と交換近傍
    入力
        l: 価値と大きさのリスト
        c: ナップサックの大きさ
        ini:初期解
    出力
        最適値(価値)
    """
    r, a, b = c, [], l # 残容量、解、未選択リスト
    while True:
        # 挿入近傍
        for p0, w0 in b:
            if w0 <= r:
                r -= w0
                a += [(p0, w0)]
                b.remove((p0, w0))
                break
        else:
            # 交換近傍
            for i in range(len(a)):
                pa, wa = a[i]
                for j in range(len(b)):
                    pb, wb = b[j]
                    if wb <= r + wa and pb > pa:
                        r -= wb - wa
                        a += [(pb, wb)]
                        a.remove((pa, wa))
                        b += [(pa, wa)]
                        b.remove((pb, wb))
                        break
                else: continue
                break
            else: break
    return sum(p0 for p0, w0 in a)

def KnapsackByCache(w, p, c, cache={}):
    """
    ナップサック問題の動的最適化法
        キャッシュを用いるトップダウン(Python3ならばfunctools.lru_cacheが使える)
    入力
        w: 大きさのリスト
        p: 価値のリスト
        c: ナップサックの大きさ
    出力
        最適値(価値)
    """
    if len(w) == 0: return 0
    if (w, p, c) in cache: return cache[(w, p, c)]
    result = max(KnapsackByCache(w[:-1], p[:-1], c),
                 KnapsackByCache(w[:-1], p[:-1], c - w[-1]) + p[-1] if c >= w[-1] else 0)
    cache[(w, p, c)] = result
    return result

if __name__ == '__main__':
    import random
    random.seed(1)
    a, t, n, c = 0, 100, 10, 50
    for i in range(t): # t回繰り返す
        w = tuple(random.randint(4, 10) for i in range(n))
        p = tuple(w[i] + random.randint(-3, 3) for i in range(n))
        if MultiStartLocalSearch(w, p, c) != KnapsackByCache(w, p, c): a += 1
    print('Exact = %.1f%%' % (100.0 * (t - a) / t))