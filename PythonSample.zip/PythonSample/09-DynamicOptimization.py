﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
def DynamicOptimization1(w, p, c):
    """
    ナップサック問題の動的最適化法
        表を用いるボトムアップ
    入力
        w: 大きさのリスト
        p: 価値のリスト
        c: ナップサックの大きさ
    出力
        最適値(価値)
    """
    n = len(p)
    t = [[0] * (c + 1) for a in range(n)]
    for b in range(w[0], c + 1): t[0][b] = p[0]
    for a in range(1, n):
        for b in range(1, c + 1):
            t[a][b] = max(t[a - 1][b],  t[a - 1][b - w[a]] + p[a] if b >= w[a] else 0)
    return t[n - 1][c]

def KnapsackByCache(w, p, c, cache={}):
    """
    ナップサック問題の動的最適化法
        キャッシュを用いるトップダウン(Python3ならばfunctools.lru_cacheが使える)
    入力
        w: 大きさのリスト
        p: 価値のリスト
        c: ナップサックの大きさ
    出力
        最適値(価値)
    """
    if len(w) == 0: return 0
    if (w, p, c) in cache: return cache[(w, p, c)]
    result = max(KnapsackByCache(w[:-1], p[:-1], c),
                 KnapsackByCache(w[:-1], p[:-1], c - w[-1]) + p[-1] if c >= w[-1] else 0)
    cache[(w, p, c)] = result
    return result

if __name__ == '__main__':
    import random
    random.seed(1)
    n, c = 10, 50
    for i in range(100): # 100回繰り返す
        w = tuple(random.randint(4, 10) for i in range(n))
        p = tuple(w[i] + random.randint(-3, 3) for i in range(n))
        if DynamicOptimization1(w, p, c) != KnapsackByCache(w, p, c):
            print('NG')
            break
    else:
        print('All OK')