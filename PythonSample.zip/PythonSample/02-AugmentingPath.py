﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
import networkx as nx
import numpy as np
def AugmentingPath(g, s, t):
    """
    フロー増加法
        2点間の最大フローを求める
    入力
        g: NetworkXのグラフ(容量は'capacity'属性とする)
        s: 始点
        t: 終点
    出力
        最大フロー
    """
    def path_from_residual(g):
        for i, j in g.edges():
            d = g.adj[i][j]
            d['weight'] = 1 if d['flow'] < d['capacity'] else np.inf
        try:
            return nx.bidirectional_dijkstra(g, s, t)
        except:
            return np.inf, []
    def change_flow(g, pth):
        mn = min(g.adj[i][j]['capacity'] - g.adj[i][j]['flow'] for i, j in zip(pth, pth[1:]))
        for i, j in zip(pth, pth[1:]):
            if i in g.adj[j] and g.adj[j][i]['flow'] >= mn:
                g.adj[j][i]['flow'] -= mn
            else:
                g.adj[i][j]['flow'] += mn
        return mn
    result = 0
    for i, j in g.edges(): g.adj[i][j]['flow'] = 0 # step 1
    while True:
        dist, pth = path_from_residual(g) # step 2
        if np.isinf(dist): break # step 2
        result += change_flow(g, pth) # step 3
    return result

if __name__ == '__main__':
    nx.random_graphs.random.seed(1)
    for i in range(100): # 100回繰り返す
        g = nx.random_graphs.fast_gnp_random_graph(20, 0.1, directed=True) # ノード数20のランダムなグラフ
        for j, k in g.edges():
            g.adj[j][k]['capacity'] = nx.random_graphs.random.randint(1, 5) # 容量を設定
        if AugmentingPath(g, 0, 1) != nx.maximum_flow_value(g, 0, 1): # NetworkXと比較
            print('NG')
            break
    else:
        print('All OK')