﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
import networkx as nx
class Graph:
    def Edmonds(self):
        """
        エドモンズ法
            無向グラフの最大マッチングを求める
        入力
            self: グラフ
        出力
            マッチングをなす辺のリスト
        """
        me = [False] * self.edge_size()
        while True:
            mn = [False] * self.node_size()
            for e in self.edges:
                if me[e.index]:
                    mn[e.from_node.index] = mn[e.to_node.index] = True
            for u in [i for i in range(self.node_size()) if not mn[i]]:
                if self.increasingPath(me, u): break
            else: break
        return [i for i, j in enumerate(me) if j]
    def __init__(self, g=None):
        self.Graph = g
        self.nodes = []
        self.edges = []
        self.shrinks = []
        if isinstance(g, nx.Graph):
            for n in g.nodes(): self.add_node()
            for i, j in g.edges(): self.add_edge(i, j)
    def enable_edges(self):
        for e in self.edges:
            if e.enable: yield e
    def node_size(self):
        return len(self.nodes)
    def edge_size(self):
        return len(self.edges)
    def add_node(self):
        self.nodes.append(Node(self.node_size()))
        return self.nodes[-1]
    def add_edge(self, fr, to, directed=False):
        edge = Edge(self.edge_size(), self.nodes[fr], self.nodes[to], directed)
        self.edges.append(edge)
        return self.edges[-1]
    def exist_edge(self, fr, to):
        for e in self.enable_edges():
            if (e.from_node.index == fr and e.to_node.index == to) or \
                (not e.directed and (e.from_node.index == to and e.to_node.index == fr)): return True
        return False
    def shrink(self, p):
        dic, nds = {}, [i[1] for i in p[:-1]]
        fst, rem = self.nodes[nds[0]], nds[1:]
        for n in rem: self.nodes[n].enable = False
        for e in self.enable_edges():
            if e.from_node.index in rem or e.to_node.index in rem:
                fr = fst if e.from_node.index in rem else e.from_node
                to = fst if e.to_node.index in rem else e.to_node
                e.enable = not self.exist_edge(fr.index, to.index) and \
                    (e.from_node.index not in nds or e.to_node.index not in nds)
                if e.enable:
                    dic[e] = e.from_node if fr == fst else e.to_node
                    e.from_node, e.to_node = fr, to
        self.shrinks.append((fst, [i[0] for i in p[1:]], dic))
    def unshrink_all(self, me):
        for n in self.nodes: n.enable = True
        for e in self.edges: e.enable = True
        for fst, pth, dic in reversed(self.shrinks):
            for e, v in dic.items():
                if e.from_node == fst: e.from_node = v
                if e.to_node == fst: e.to_node = v
                if v != fst and me[e.index]:
                    pth2 = pth * 2
                    for i, (e1, e2) in enumerate(zip(pth2, pth2[1:])):
                        if e1.has(v) and e2.has(v):
                            pth1 = pth2[i:i + len(pth)]
                            for f in pth1[:2]: me[f.index] = False
                            for j, f in enumerate(pth1[2:]):
                                me[f.index] = j % 2 == 0
                            break
        self.shrinks = []
    def increasingPath(self, me, u):
        p, fn, fe = [(None, u)], [False] * self.node_size(), [False] * self.edge_size()
        while True:
            w = self.nodes[p[-1][1]] # Pの最後の点
            assert(w.enable)
            for e in [f for f in self.edges if f.has(w)]:
                v = e.another(w)
                if not fe[e.index]: # wに未処理の辺eがある
                    if fn[v.index] or v.index in (i[1] for i in p[1::2]):
                        fe[e.index] = True
                        break
                    for i, (e1, n1) in enumerate(p[::2]):
                        if n1 == v.index:
                            self.shrink(p[i * 2:] + [(e, v.index)])
                            p = p[:i * 2 + 1]
                            break
                    else:
                        for e2 in [self.edges[j] for j, f in enumerate(me) if f]:
                            if e2.from_node == v or e2.to_node == v:
                                p.append((e, v.index))
                                p.append((e2, e2.another(v).index))
                                break
                        else:
                            for e3, n3 in p[1:] + [(e, v.index)]:
                                me[e3.index] = not me[e3.index]
                            self.unshrink_all(me)
                            return True
                    break
            else:
                if len(p) == 1:
                    self.unshrink_all(me)
                    return False
                else:
                    fn[w.index] = fn[self.nodes[p[-2][1]].index] = True
                    p = p[:-2]

class Edge:
    def __init__(self, index, from_node, to_node, directed=False):
        self.enable = True
        self.index = index
        self.directed = directed
        self.from_node = from_node
        self.to_node = to_node
    def another(self, n):
        return self.from_node if n == self.to_node else \
            (self.to_node if n == self.from_node else None)
    def has(self, n):
        return self.enable and (n == self.from_node or n == self.to_node)
    def __repr__(self):
        return '%s%d(%d-%s%d)' % ('' if self.enable else '!', self.index,
            self.from_node.index, ('>' if self.directed else ''), self.to_node.index)

class Node:
    def __init__(self, index):
        self.enable = True
        self.index = index
    def __repr__(self):
        return '<%s%d>' % ('' if self.enable else '!', self.index)

if __name__ == '__main__':
    nx.random_graphs.random.seed(1)
    for i in range(100): # 100回繰り返す
        g = Graph(nx.random_graphs.fast_gnp_random_graph(20, 0.1)) # ノード数20のランダムなグラフ
        if len(g.Edmonds()) != len(nx.max_weight_matching(g.Graph)) // 2: # NetworkXと比較
            print('NG')
            break
    else:
        print('All OK')