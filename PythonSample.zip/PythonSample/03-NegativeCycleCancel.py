﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
"""
import networkx as nx
import numpy as np
def NegativeCycleCancel(g0):
    """
    負閉路除去法
        最小費用流問題を解く
    入力
        g0: NetworkXのグラフ(需要は'demand', 重みは'weight', 容量は'weight'属性とする)
    出力
        フローを表す辞書
    """
    g = g0.copy()
    # initial flow
    for i, j in g.edges():
        g.get_edge_data(i, j)['flow'] = 0
    for i in g.nodes():
        d = g.node[i]['demand']
        if d > 0:
            g.add_edge(-1, i, capacity=d, flow=d, weight=999999)
            g.add_edge(i, -1, capacity=d, flow=0, weight=-999999)
        elif d < 0:
            g.add_edge(i, -1, capacity=-d, flow=-d, weight=999999)
            g.add_edge(-1, i, capacity=-d, flow=0, weight=-999999)
    while True:
        for c in nx.cycles.simple_cycles(g):
            if len(c) == 2: continue
            s = sum(getw(g, *e) for e in zip([c[-1]] + c, c))
            if s < 0: # detect negative cycle
                mn = min(rema(g, *e) for e in zip([c[-1]] + c, c))
                if mn > 0: # can flow
                    for e in zip([c[-1]] + c, c):
                        d = g.get_edge_data(*e)
                        v = g.get_edge_data(e[1], e[0])
                        if v['flow'] > 0:
                            v['flow'] -= mn
                            if v['flow'] < 1e-6:
                                d['weight'] = v['weight']
                        else:
                            d['flow'] += mn
                            v['weight'] = -d['weight']
                    break
        else:
            break
    g.remove_node(-1)
    return {k:{q:v['flow'] for q, v in d.items()} for k, d in g.adj.items()}

def getw(g, i, j):
    d = g.get_edge_data(i, j)
    return d['weight'] if d['flow'] < d['capacity'] - 1e-6 else 999999

def rema(g, i, j):
    d = g.get_edge_data(i, j)
    v = g.get_edge_data(j, i)
    return v['flow'] if v['flow'] > 1e-6 else d['capacity'] - d['flow']

if __name__ == '__main__':
    nx.random_graphs.random.seed(1)
    for i in range(10): # 10回繰り返す
        while True:
            g = nx.random_graphs.fast_gnp_random_graph(6, 0.5)
            if nx.is_connected(g):
                d = [nx.random_graphs.random.randint(-2, 2) for i in range(g.number_of_nodes() - 1)]
                d += [-sum(d)]
                for i in g.nodes():
                    g.node[i]['demand'] = d[i]
                for i, j in g.edges():
                    g.get_edge_data(i, j)['capacity'] = nx.random_graphs.random.randint(1, 4)
                    g.get_edge_data(i, j)['weight'] = nx.random_graphs.random.random() * 100 + 10
                g = g.to_directed()
                try:
                    r = nx.min_cost_flow(g)
                    break
                except:
                    pass
        ncc = NegativeCycleCancel(g)
        if ncc != r: # NetworkXと比較
            print('NG')
            print(r)
            print(ncc)
            break
    else:
        print('All OK')