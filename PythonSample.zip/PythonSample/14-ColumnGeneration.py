﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
from pulp import *
import numpy as np
def ColumnGeneration(c, w):
    """
    列生成法
        ビンパッキング問題を解く
    入力
        c: ビンの大きさ
        w: 荷物の大きさのリスト
    出力
        ビンごとの荷物の大きさリスト
    備考
        pulpのインストール方法 : pip install pulp
    """
    n = len(w)
    rn = range(n)
    mkp = LpProblem('knapsack', LpMaximize) # 子問題
    mkpva = [addvar(cat=LpBinary) for i in rn]
    mkp.addConstraint(lpDot(w, mkpva) <= c)
    mdl = LpProblem('dual', LpMaximize) # 双対問題
    mdlva = [addvar() for i in rn]
    for i, v in enumerate(mdlva): v.w = w[i]
    mdl.setObjective(lpSum(mdlva))
    for i in rn:
        mdl.addConstraint(mdlva[i] <= 1)
    while True:
        mdl.solve()
        mkp.setObjective(lpDot([value(v) for v in mdlva], mkpva))
        mkp.solve()
        if mkp.status != 1 or value(mkp.objective) < 1 + 1e-6: break
        mdl.addConstraint(lpDot([value(v) for v in mkpva], mdlva) <= 1)
    nwm = LpProblem('primal', LpMinimize) # 主問題
    nm = len(mdl.constraints)
    rm = range(nm)
    nwmva = [addvar(cat=LpBinary) for i in rm]
    nwm.setObjective(lpSum(nwmva))
    dict = {}
    for v, q in mdl.objective.items():
        dict[v] = LpAffineExpression() >= q
    const = list(mdl.constraints.values())
    for i, q in enumerate(const):
        for v in q:
            dict[v].addterm(nwmva[i], 1)
    for q in dict.values(): nwm.addConstraint(q)
    nwm.solve()
    if nwm.status != 1: return None
    w0, result = list(w), [[] for i in range(len(const))]
    for i, va in enumerate(nwmva):
        if value(va) < 0.5: continue
        for v in const[i]:
            if v.w in w0:
                w0.remove(v.w)
                result[i].append(v.w)
    return [r for r in result if r]

def addvar(lowBound=0, var_count=[0], *args, **kwargs):
    """変数作成"""
    var_count[0] += 1
    return LpVariable('v%d' % var_count[0], lowBound=lowBound, *args, **kwargs)

def ColumnGeneration2(c, w):
    """比較用"""
    n = len(w)
    rn = range(n)
    m = LpProblem()
    x = [[addvar(cat=LpBinary) for j in rn] for i in rn]
    y = [addvar(cat=LpBinary) for i in rn]
    m.setObjective(lpSum(y))
    for i in rn:
        m.addConstraint(lpDot(w, x[i]) <= c * y[i])
        m.addConstraint(lpSum(x[j][i] for j in rn) == 1)
    m.solve()
    return int(value(m.objective))

if __name__ == '__main__':
    np.random.seed(1)
    for i in range(2): # 2回繰り返す
        c, w = 10, np.random.randint(1, 6, 10)
        if len(ColumnGeneration(c, w)) != ColumnGeneration2(c, w):
            print('NG')
            break
    else:
        print('All OK')