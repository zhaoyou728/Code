﻿# coding: utf-8
"""
今日から使える！組合せ最適化
本プログラムは、上記書籍の理解を助ける目的のサンプルプログラムです。
完全に正しいことを証明するものではありません。
直接販売することを除き、商用でも無料で利用できます。
利用において、損害等が発生しても利用者の責任とします。
License: Python Software Foundation License
"""
from __future__ import print_function, division
import numpy as np
def InteriorPoint(A, b, c, alpha=0.01, delta=0.01):
    """
    内点法
        min: c^T * x
        s.t.: Ax = b, x >= 0
    入力
        A, b, c: 上記式の通り
    出力
        最適値
    備考
        自明な初期解から始められるように基底変数、非基底変数の順に並んでいるとする
        自明な初期解が内点にあるものとする
        最適解の成分に0に近いものはないものとする
        実行可能領域の壁に近づきしないように工夫をするべきだがしていない
    """
    n, m = len(c), len(b) # 変数数, 制約数
    bs = list(range(m))
    x = np.r_[np.dot(np.linalg.inv(A.T[bs].T), b), np.zeros(n - m)]
    assert(np.linalg.det(A.T[bs]) > 1e-6 and np.all(x >= 0))
    y = -np.ones(m)
    v = c - np.dot(A.T, y)
    assert(np.all(v >= 0))
    for cnt in range(1000):
        rho = delta * np.dot(x, v) / n
        if rho < 1e-6: # 主双対最適性条件のチェックは省略
            break
        M = np.r_[np.c_[A, np.zeros((m, n + m))],
                  np.c_[np.zeros((n, n)), A.T, np.eye(n)],
                  np.c_[np.diag(v), np.zeros((n, m)), np.diag(x)]]
        V = np.r_[np.dot(A, x) - b, np.dot(A.T, y) + v - c, x * v - rho]
        d = np.linalg.solve(M, -V)
        stp, xyv = alpha, np.r_[x, y, v]
        while stp > 1e-12: # ここでは簡易的に実行可能領域にとどまるようにしている
            nw = xyv + stp * d
            if all(nw[:n] >= 0) or all(nw[n+m:] >= 0): break
            stp /= 2
        x, y, v = nw[:n], nw[n:n + m], nw[n+m:]
    else:
        print('Iterations exceeded')
    return np.dot(c, x)

from pulp import *
def LinearOptimize(A, b, c):
    m = LpProblem()
    x = [LpVariable('x%d' % i, lowBound=0) for i in range(len(c))]
    m.setObjective(lpDot(c, x))
    for j in range(len(b)): m.addConstraint(lpDot(A[j], x) == b[j])
    m.solve()
    return value(m.objective) if m.status == 1 else np.nan, [value(v) for v in x]

if __name__ == '__main__':
    np.random.seed(1)
    n, m = 20, 13
    for i in range(10): # 10回繰り返す
        N = np.random.random((m, n - m))
        N /= N.sum(axis=0)
        A = np.c_[np.eye(m), N]
        b = np.random.random(m)
        c = -np.random.random(n)
        r = LinearOptimize(A, b, c)
        if min(r[1]) < 1e-4:
            continue
        r2 = round(r[0], 2)
        r1 = round(InteriorPoint(A, b, c), 2)
        if abs(r1 - r2) > 0.02:
            print('NG')
            break
    else:
        print('All OK')