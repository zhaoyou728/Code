# PriceOptimizer in C++

## Install
```
brew install python3 boost gcc
brew install --build-from-source boost-python --with-python3
make
```


## Test
`python3 test.py`