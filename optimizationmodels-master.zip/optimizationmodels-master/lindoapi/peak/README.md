## Brief Introduction

**Tools**
- [`Lindo API`](http://www.lindo.com)

**Version**: 11.0

**Files**
- peak.c: Implementation for `peak.lng` using [`C API`](http://www.lindo.com/downloads/PDF/API.pdf) with `Local/Global Optimizer`
- Makefile: NMake makefile

**Contact**
 - `wujianjack2@163.com`      (personal)
 - `wujianw@stu.xjtu.edu.cn`  (educational)

 **Wu Jian**
 
 `July 15th, 2017`