## Brief Introduction

**Tools**
- [`Lindo API`](http://www.lindo.com)

**Version**: 11.0

**Files**
- circle.c: Implementation for `circle.lng` using [`C API`](http://www.lindo.com/downloads/PDF/API.pdf) with `Multistart Optimizer`
- Makefile: NMake makefile

**Contact**
 - `wujianjack2@163.com`      (personal)
 - `wujianw@stu.xjtu.edu.cn`  (educational)

 **Wu Jian**
 
 `July 16th, 2017`